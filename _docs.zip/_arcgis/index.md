# R-ArcGIS Bridge

# R-ArcGIS Bridge

The R-ArcGIS Bridge is a collection of R packages designed to integrate the R language with the ArcGIS Ecosystem. The R-ArcGIS Bridge can be used to:

- Create R-based geoprocessing tools
- Access and publish data on ArcGIS Online, Enterprise, or Platform
- Geocode addresses at scale
- Access detailed point of interest (POI) data

<img
src="https://raw.githubusercontent.com/R-ArcGIS/arcgislayers/main/man/figures/logo.svg"
style="width:70.0%" />

## Where to start

1.  Discover key features of the R-ArcGIS Bridge.
2.  Install the R packages.
3.  Explore tutorials and sample code.
