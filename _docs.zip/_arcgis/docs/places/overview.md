# Overview

[arcgisplaces](https://github.com/R-ArcGIS/arcgisplaces) is an R package to interface with [ArcGIS Places Service](https://developers.arcgis.com/rest/places/).

> The places service is a ready-to-use location service that can search for businesses and geographic locations around the world. It allows you to find, locate, and discover detailed information about each place.

In order to use [arcgisplaces](https://github.com/R-ArcGIS/arcgisplaces) you will need an ArcGIS Developers account. [Get started here](https://developers.arcgis.com/documentation/mapping-apis-and-services/get-started/).

## Installation

[arcgisplaces](https://github.com/R-ArcGIS/arcgisplaces) can be installed directly from R-universe using

<pre class='chroma'>
<span><span class='nf'><a href='https://rdrr.io/r/utils/install.packages.html'>install.packages</a></span><span class='o'>(</span><span class='s'>"arcgisplaces"</span><span class='o'>)</span></span></pre>

## Usage

The Places service enables you to find points of interest (POI) based on a location or a bounding box as well as filter your results based on a category or search text.

Finding places:

- `near_point()`: search for places near a location.
- `within_extent()`: search for places within an extent.
- `place_details()`: get detailed information about the places returned from `near_point()` or `within_extent()`.
  - Note: see `fields` for the possible attributes to return for place details.

Understanding categories:

- `categories()`: find categories by name or ID.

- `category_details()`: get detailed information about the categories returned from `categories()`.

- Find place attributes such as name, address, description, opening hours, price ratings, user ratings, and social links.

## Examples

`arcgisutils` is needed for authentication. The Places API supports either using an API key via `auth_key()` or one generated via OAuth2 using either `auth_client()` or `auth_code()`. See [API documentation](https://developers.arcgis.com/rest/places/#authentication) for more.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgisutils'>arcgisutils</a></span><span class='o'>)</span></span>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgisplaces'>arcgisplaces</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Authenticate with a Developer Account API Key</span></span>
<span><span class='nv'>token</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/auth.html'>auth_key</a></span><span class='o'>(</span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/token.html'>set_arc_token</a></span><span class='o'>(</span><span class='nv'>token</span><span class='o'>)</span></span></pre>

## Place search

You can **search for places near a location** with [`near_point()`](https://r.esri.com/arcgisplaces/reference/near_point.html).

<pre class='chroma'>
<span><span class='nv'>coffee</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://r.esri.com/arcgisplaces/reference/near_point.html'>near_point</a></span><span class='o'>(</span></span>
<span>  x <span class='o'>=</span> <span class='o'>-</span><span class='m'>122.3408</span>, </span>
<span>  y <span class='o'>=</span> <span class='m'>47.62045</span>, </span>
<span>  search_text <span class='o'>=</span> <span class='s'>"Coffee"</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>coffee</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 188 features and 5 fields</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -122.3538 ymin: 47.61173 xmax: -122.3298 ymax: 47.62903</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A data frame: 188 × 6</span></span>
<span><span class='c'>#&gt;    place_id                name  distance categories icon              geometry</span></span>
<span><span class='c'>#&gt;  * &lt;chr&gt;                   &lt;chr&gt;    &lt;dbl&gt; &lt;I&lt;list&gt;&gt;  &lt;chr&gt;          &lt;POINT [°]&gt;</span></span>
<span><span class='c'>#&gt;  1 5544867893cfb98075a343… Evok…     81.6 &lt;df&gt;       &lt;NA&gt;  (-122.3398 47.62078)</span></span>
<span><span class='c'>#&gt;  2 bce59758cec5dbd41164af… Café…     92.9 &lt;df&gt;       &lt;NA&gt;     (-122.34 47.6211)</span></span>
<span><span class='c'>#&gt;  3 a54982e9d33423bb0cacd1… Toas…    138.  &lt;df&gt;       &lt;NA&gt;  (-122.3426 47.62014)</span></span>
<span><span class='c'>#&gt;  4 2976ac85a2172548279f64… Herk…    147.  &lt;df&gt;       &lt;NA&gt;  (-122.3396 47.62151)</span></span>
<span><span class='c'>#&gt;  5 42f3e72e7e4a3e96e9e02c… Papa…    150.  &lt;df&gt;       &lt;NA&gt;  (-122.3397 47.62156)</span></span>
<span><span class='c'>#&gt;  6 08b5207a065fc6df28ba2c… Yell…    172.  &lt;df&gt;       &lt;NA&gt;  (-122.3386 47.62094)</span></span>
<span><span class='c'>#&gt;  7 dd32a24cfb739f6a33e640… Mi T…    174.  &lt;df&gt;       &lt;NA&gt;  (-122.3388 47.62129)</span></span>
<span><span class='c'>#&gt;  8 81e1117c45a9b070e66b53… Male…    196.  &lt;df&gt;       &lt;NA&gt;  (-122.3392 47.62186)</span></span>
<span><span class='c'>#&gt;  9 f3858c5aecfb54d4aa64d9… Star…    209   &lt;df&gt;       &lt;NA&gt;  (-122.3385 47.62154)</span></span>
<span><span class='c'>#&gt; 10 1752703707ed0f67ece99d… Cafe…    210.  &lt;df&gt;       &lt;NA&gt;   (-122.338 47.62016)</span></span>
<span><span class='c'>#&gt; # ℹ 178 more rows</span></span></pre>

Locations are returned as an sf object with the place ID, the place name, distance from the search point, a character vector of categories.

<div class="callout-tip">

`arcgisplaces` will return an sf object, but the sf package is not required to work with the package. The `sf` print method will not be used unless the package is loaded. If package size is a consideration—i.e. deploying an app in a Docker container—consider using `wk` or `geos`.

</div>

Details for the places can be fetched using [`place_details()`](https://r.esri.com/arcgisplaces/reference/place_details.html). The possible fields are [documented online](https://developers.arcgis.com/rest/places/place-id-get/#requestedfields) as well as contained in the exported vector `fields`. Because pricing is dependent upon which fields are requested, it is a required argument.

To fiew possible fields for places details use [`arcgisplaces::fields`](https://r.esri.com/arcgisplaces/reference/fields.html).

<pre class='chroma'>
<span><span class='nv'>details</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://r.esri.com/arcgisplaces/reference/place_details.html'>place_details</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>coffee</span><span class='o'>$</span><span class='nv'>place_id</span>,</span>
<span>  requested_fields <span class='o'>=</span> <span class='s'>"all"</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>details</span><span class='o'>[</span><span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='s'>"name"</span>, <span class='s'>"website"</span><span class='o'>)</span><span class='o'>]</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 188 features and 2 fields</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -122.3538 ymin: 47.61173 xmax: -122.3298 ymax: 47.62903</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A data frame: 188 × 3</span></span>
<span><span class='c'>#&gt;    name                 website                                        location</span></span>
<span><span class='c'>#&gt;  * &lt;chr&gt;                &lt;chr&gt;                                       &lt;POINT [°]&gt;</span></span>
<span><span class='c'>#&gt;  1 Evoke Coffee Co      https://evokeespresso.com          (-122.3398 47.62078)</span></span>
<span><span class='c'>#&gt;  2 Café An'Claire       &lt;NA&gt;                                  (-122.34 47.6211)</span></span>
<span><span class='c'>#&gt;  3 Toast To Toast       &lt;NA&gt;                               (-122.3426 47.62014)</span></span>
<span><span class='c'>#&gt;  4 Herkimer Coffee      &lt;NA&gt;                               (-122.3396 47.62151)</span></span>
<span><span class='c'>#&gt;  5 Papa Poy-yo          http://cafes.compass-usa.com/Amaz… (-122.3397 47.62156)</span></span>
<span><span class='c'>#&gt;  6 Yellow Dot Cafe      http://yellowdotcafe.com           (-122.3386 47.62094)</span></span>
<span><span class='c'>#&gt;  7 Mi Tea               &lt;NA&gt;                               (-122.3388 47.62129)</span></span>
<span><span class='c'>#&gt;  8 Maleng Building Café &lt;NA&gt;                               (-122.3392 47.62186)</span></span>
<span><span class='c'>#&gt;  9 Starbucks            https://www.starbucks.com          (-122.3385 47.62154)</span></span>
<span><span class='c'>#&gt; 10 Cafe Moby in Roxanne &lt;NA&gt;                                (-122.338 47.62016)</span></span>
<span><span class='c'>#&gt; # ℹ 178 more rows</span></span></pre>

Or, you can search for places within a bounding box using [`within_extent()`](https://r.esri.com/arcgisplaces/reference/within_extent.html). This could be quite handy for searching within current map bounds, for example.

<pre class='chroma'>
<span><span class='nv'>coffee_shops</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://r.esri.com/arcgisplaces/reference/within_extent.html'>within_extent</a></span><span class='o'>(</span></span>
<span>  <span class='o'>-</span><span class='m'>70.356</span>, <span class='m'>43.588</span>, <span class='o'>-</span><span class='m'>70.176</span>, <span class='m'>43.7182</span>,</span>
<span>  category_id <span class='o'>=</span> <span class='s'>"4bf58dd8d48988d1e0931735"</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>coffee_shops</span><span class='o'>[</span><span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='s'>"name"</span><span class='o'>)</span><span class='o'>]</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 80 features and 1 field</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -70.356 ymin: 43.588 xmax: -70.176 ymax: 43.7182</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A data frame: 80 × 2</span></span>
<span><span class='c'>#&gt;    name                             geometry</span></span>
<span><span class='c'>#&gt;  * &lt;chr&gt;                         &lt;POINT [°]&gt;</span></span>
<span><span class='c'>#&gt;  1 Middle Street Cafe   (-70.25169 43.65877)</span></span>
<span><span class='c'>#&gt;  2 HiFi                 (-70.25785 43.65712)</span></span>
<span><span class='c'>#&gt;  3 Speckled Ax           (-70.24799 43.6598)</span></span>
<span><span class='c'>#&gt;  4 Yordprom Coffee Shop (-70.26945 43.65291)</span></span>
<span><span class='c'>#&gt;  5 Buzz Coffee          (-70.25361 43.65695)</span></span>
<span><span class='c'>#&gt;  6 Coffee By Design     (-70.25674 43.66608)</span></span>
<span><span class='c'>#&gt;  7 Aroma Joe’s          (-70.30434 43.62121)</span></span>
<span><span class='c'>#&gt;  8 Mister Bagel          (-70.3328 43.63843)</span></span>
<span><span class='c'>#&gt;  9 Starbucks            (-70.33097 43.59148)</span></span>
<span><span class='c'>#&gt; 10 Scratch Baking Co.   (-70.23063 43.63929)</span></span>
<span><span class='c'>#&gt; # ℹ 70 more rows</span></span></pre>
