# Bulk geocoding

Bulk geocoding capabilities are provided via the `geocode_addresses()` function in [arcgisgeocode](https://github.com/r-arcgis/arcgisgeocode). Rather geocoding a single address and returning match candidates, the bulk geocoding capabilities take many addresses and geocode them all at once returning a single location per address.

Using the bulk geocoding capabilities can result in incurring a cost. See more about [geocoding pricing](https://developers.arcgis.com/documentation/mapping-apis-and-services/geocoding/services/geocoding-service/#pricing).

In this example, you will geocode restaurant addresses in Boston, MA collected by the [Boston Area Research Initiative (BARI)](https://cssh.northeastern.edu/bari/). The data is originally from their [data portal](https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/DMWCBT).

## Step 1. Authenticate

In order to utilize the bulk geocoding capabilities of the ArcGIS World Geocoder, you must first authenticate using [arcgisutils](https://github.com/R-ArcGIS/arcgisutils). In this example, we are using user-based authentication via `auth_user()`. You may choose a different authentication function if it works better for you.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgisutils'>arcgisutils</a></span><span class='o'>)</span></span>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/r-arcgis/arcgisgeocode'>arcgisgeocode</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/token.html'>set_arc_token</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/auth.html'>auth_user</a></span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span></pre>

## Step 2. Prepare the data

Similar to using [`find_address_candidates()`](https://rdrr.io/pkg/arcgisgeocode/man/find_address_candidates.html) the geocoding results return an ID that can be used to join back onto the original dataset. First, you will read in the dataset from a filepath using [`readr::read_csv()`](https://readr.tidyverse.org/reference/read_delim.html) and then create a unique identifier with [`dplyr::mutate()`](https://dplyr.tidyverse.org/reference/mutate.html) and [`dplyr::row_number()`](https://dplyr.tidyverse.org/reference/row_number.html).

<pre class='chroma'>
<span><span class='c'># Boston Yelp addresses</span></span>
<span><span class='c'># Source: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/DMWCBT</span></span>
<span><span class='nv'>fp</span> <span class='o'>&lt;-</span> <span class='s'>"https://analysis-1.maps.arcgis.com/sharing/rest/content/items/0423768816b343b69d9a425b82351912/data"</span></span>
<span></span>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://dplyr.tidyverse.org'>dplyr</a></span><span class='o'>)</span></span>
<span><span class='nv'>restaurants</span> <span class='o'>&lt;-</span> <span class='nf'>readr</span><span class='nf'>::</span><span class='nf'><a href='https://readr.tidyverse.org/reference/read_delim.html'>read_csv</a></span><span class='o'>(</span><span class='nv'>fp</span><span class='o'>)</span> <span class='o'>|&gt;</span></span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/mutate.html'>mutate</a></span><span class='o'>(</span>id <span class='o'>=</span> <span class='nf'><a href='https://dplyr.tidyverse.org/reference/row_number.html'>row_number</a></span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>restaurants</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; # A tibble: 2,664 × 28</span></span>
<span><span class='c'>#&gt;    restaurant_name      restaurant_ID restaurant_address restaurant_tag rating price</span></span>
<span><span class='c'>#&gt;    &lt;chr&gt;                        &lt;dbl&gt; &lt;chr&gt;              &lt;chr&gt;           &lt;dbl&gt; &lt;chr&gt;</span></span>
<span><span class='c'>#&gt;  1 100% Delicias                    2 635 Hyde Park Ave… Latin America…    2   $$   </span></span>
<span><span class='c'>#&gt;  2 100% Delicias Expre…             3 660A Centre St,Ja… Dominican,Emp…    4   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  3 107                              4 107 Salem St,Bost… Restaurants,     NA   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  4 140 Supper Club                  6 138 St James Ave,… Diners,           5   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  5 163 Vietnamese Sand…             7 66 Harrison Ave,B… Vietnamese,Co…    3.5 $    </span></span>
<span><span class='c'>#&gt;  6 180 Cafe                         8 23 Edinboro St,Bo… Cafes,            4   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  7 180 Restaurant and …             9 174 Lincoln St,Bo… Restaurants,     NA   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  8 224 Boston Street R…            11 224 Boston St,Dor… American (New…    4   $$   </span></span>
<span><span class='c'>#&gt;  9 24 Hour Pizza Deliv…            12 686 Morton St,Bos… Pizza,            1   $$$$ </span></span>
<span><span class='c'>#&gt; 10 2Twenty2                        13 222 Friend St,Bos… Asian Fusion,…    3   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt; # ℹ 2,654 more rows</span></span>
<span><span class='c'>#&gt; # ℹ 22 more variables: review_number &lt;dbl&gt;, unique_reviewer &lt;dbl&gt;,</span></span>
<span><span class='c'>#&gt; #   reviews_Jan_19 &lt;dbl&gt;, reviews_Feb_19 &lt;dbl&gt;, reviews_Mar_19 &lt;dbl&gt;,</span></span>
<span><span class='c'>#&gt; #   reviews_Apr_19 &lt;dbl&gt;, reviews_May_19 &lt;dbl&gt;, reviews_Jun_19 &lt;dbl&gt;,</span></span>
<span><span class='c'>#&gt; #   reviews_Jul_19 &lt;dbl&gt;, reviews_Aug_19 &lt;dbl&gt;, reviews_Jan_20 &lt;dbl&gt;,</span></span>
<span><span class='c'>#&gt; #   reviews_Feb_20 &lt;dbl&gt;, reviews_Mar_20 &lt;dbl&gt;, reviews_Apr_20 &lt;dbl&gt;,</span></span>
<span><span class='c'>#&gt; #   reviews_May_20 &lt;dbl&gt;, reviews_Jun_20 &lt;dbl&gt;, reviews_Jul_20 &lt;dbl&gt;, …</span></span></pre>

## Step 3. Geocode addresses

The restaurant addresses are contained in the `restaurant_address` column. Pass this column into the `single_line` argument of [`geocode_addresses()`](https://rdrr.io/pkg/arcgisgeocode/man/geocode_addresses.html) and store the results in `geocoded`.

<pre class='chroma'>
<span><span class='nv'>geocoded</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/geocode_addresses.html'>geocode_addresses</a></span><span class='o'>(</span></span>
<span>  single_line <span class='o'>=</span> <span class='nv'>restaurants</span><span class='o'>[[</span><span class='s'>"restaurant_address"</span><span class='o'>]</span><span class='o'>]</span>, </span>
<span>  .progress <span class='o'>=</span> <span class='kc'>FALSE</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># preview the first 10 columns</span></span>
<span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>geocoded</span><span class='o'>[</span>, <span class='m'>1</span><span class='o'>:</span><span class='m'>10</span><span class='o'>]</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 2,664</span></span>
<span><span class='c'>#&gt; Columns: 11</span></span>
<span><span class='c'>#&gt; $ result_id   &lt;int&gt; 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,…</span></span>
<span><span class='c'>#&gt; $ loc_name    &lt;chr&gt; "World", "World", "World", "World", "World", "World", "World",…</span></span>
<span><span class='c'>#&gt; $ status      &lt;chr&gt; "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", "M…</span></span>
<span><span class='c'>#&gt; $ score       &lt;dbl&gt; 100.00, 100.00, 100.00, 100.00, 100.00, 100.00, 100.00, 100.00…</span></span>
<span><span class='c'>#&gt; $ match_addr  &lt;chr&gt; "635 Hyde Park Avenue, Roslindale, Massachusetts, 02131", "660…</span></span>
<span><span class='c'>#&gt; $ long_label  &lt;chr&gt; "635 Hyde Park Avenue, Roslindale, MA, 02131, USA", "660A Cent…</span></span>
<span><span class='c'>#&gt; $ short_label &lt;chr&gt; "635 Hyde Park Avenue", "660A Centre Street", "107 Salem Stree…</span></span>
<span><span class='c'>#&gt; $ addr_type   &lt;chr&gt; "PointAddress", "PointAddress", "PointAddress", "PointAddress"…</span></span>
<span><span class='c'>#&gt; $ type_field  &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ place_name  &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ geometry    &lt;POINT [°]&gt; POINT (-71.11936 42.27857), POINT (-71.11386 42.31285), …</span></span></pre>

<div class="callout-tip">

You can use [`dplyr::reframe()`](https://dplyr.tidyverse.org/reference/reframe.html) to geocode these addresses in a dplyr-friendly way.

</div>

## Step 4. Join the results

In the previous step you geocoded the addresses and returned a data frame containing the location information. More likely than not, it would be helpful to have the locations joined onto the original dataset. You can do this by using [`dplyr::left_join()`](https://dplyr.tidyverse.org/reference/mutate-joins.html) and joining on the `id` column you created and the `result_id` from the geocoding results.

<pre class='chroma'>
<span><span class='nv'>joined_addresses</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://dplyr.tidyverse.org/reference/mutate-joins.html'>left_join</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>restaurants</span>,</span>
<span>  <span class='nv'>geocoded</span>,</span>
<span>  by <span class='o'>=</span> <span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='s'>"id"</span> <span class='o'>=</span> <span class='s'>"result_id"</span><span class='o'>)</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nf'>dplyr</span><span class='nf'>::</span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>joined_addresses</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 2,664</span></span>
<span><span class='c'>#&gt; Columns: 90</span></span>
<span><span class='c'>#&gt; $ restaurant_name         &lt;chr&gt; "100% Delicias", "100% Delicias Express", "107", "…</span></span>
<span><span class='c'>#&gt; $ restaurant_ID           &lt;dbl&gt; 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 16, 17, 18, 21, 2…</span></span>
<span><span class='c'>#&gt; $ restaurant_address      &lt;chr&gt; "635 Hyde Park Ave,Roslindale, MA 02131,", "660A C…</span></span>
<span><span class='c'>#&gt; $ restaurant_tag          &lt;chr&gt; "Latin American,Dominican,", "Dominican,Empanadas,…</span></span>
<span><span class='c'>#&gt; $ rating                  &lt;dbl&gt; 2.0, 4.0, NA, 5.0, 3.5, 4.0, NA, 4.0, 1.0, 3.0, 4.…</span></span>
<span><span class='c'>#&gt; $ price                   &lt;chr&gt; "$$", NA, NA, NA, "$", NA, NA, "$$", "$$$$", NA, N…</span></span>
<span><span class='c'>#&gt; $ review_number           &lt;dbl&gt; 37, 26, 0, 1, 335, 8, 0, 248, 31, 63, 10, 232, 77,…</span></span>
<span><span class='c'>#&gt; $ unique_reviewer         &lt;dbl&gt; 34, 25, 0, 1, 335, 8, 0, 248, 31, 63, 10, 232, 77,…</span></span>
<span><span class='c'>#&gt; $ reviews_Jan_19          &lt;dbl&gt; 0, 1, 0, 0, 0, 0, 0, 1, 0, 8, 0, 1, 7, 0, 1, 0, 2,…</span></span>
<span><span class='c'>#&gt; $ reviews_Feb_19          &lt;dbl&gt; 1, 2, 0, 0, 0, 0, 0, 4, 0, 3, 0, 0, 2, 0, 0, 0, 4,…</span></span>
<span><span class='c'>#&gt; $ reviews_Mar_19          &lt;dbl&gt; 1, 3, 0, 0, 0, 1, 0, 5, 1, 2, 0, 0, 3, 0, 2, 0, 1,…</span></span>
<span><span class='c'>#&gt; $ reviews_Apr_19          &lt;dbl&gt; 0, 3, 0, 0, 1, 0, 0, 3, 0, 4, 0, 3, 5, 0, 0, 0, 3,…</span></span>
<span><span class='c'>#&gt; $ reviews_May_19          &lt;dbl&gt; 2, 1, 0, 0, 1, 0, 0, 1, 0, 2, 0, 0, 6, 0, 0, 0, 2,…</span></span>
<span><span class='c'>#&gt; $ reviews_Jun_19          &lt;dbl&gt; 0, 0, 0, 0, 1, 0, 0, 1, 0, 4, 0, 1, 3, 0, 0, 0, 1,…</span></span>
<span><span class='c'>#&gt; $ reviews_Jul_19          &lt;dbl&gt; 0, 1, 0, 0, 3, 1, 0, 4, 1, 0, 4, 0, 3, 0, 2, 0, 4,…</span></span>
<span><span class='c'>#&gt; $ reviews_Aug_19          &lt;dbl&gt; 0, 7, 0, 0, 0, 0, 0, 3, 0, 7, 3, 0, 0, 0, 0, 0, 5,…</span></span>
<span><span class='c'>#&gt; $ reviews_Jan_20          &lt;dbl&gt; 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 5, 1, 0, 0, 4,…</span></span>
<span><span class='c'>#&gt; $ reviews_Feb_20          &lt;dbl&gt; 0, 1, 0, 0, 1, 0, 0, 2, 0, 2, 1, 3, 8, 6, 0, 0, 3,…</span></span>
<span><span class='c'>#&gt; $ reviews_Mar_20          &lt;dbl&gt; 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 6, 0, 0, 1,…</span></span>
<span><span class='c'>#&gt; $ reviews_Apr_20          &lt;dbl&gt; 1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 0, 0, 1,…</span></span>
<span><span class='c'>#&gt; $ reviews_May_20          &lt;dbl&gt; 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,…</span></span>
<span><span class='c'>#&gt; $ reviews_Jun_20          &lt;dbl&gt; 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 6, 0, 0, 0,…</span></span>
<span><span class='c'>#&gt; $ reviews_Jul_20          &lt;dbl&gt; 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 3, 0, 0,…</span></span>
<span><span class='c'>#&gt; $ reviews_Aug_20          &lt;dbl&gt; 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 4, 1, 0, 0,…</span></span>
<span><span class='c'>#&gt; $ restaurant_neighborhood &lt;chr&gt; "Roslindale", "Jamaica Plain", "Boston", "Boston",…</span></span>
<span><span class='c'>#&gt; $ GIS_ID                  &lt;dbl&gt; 1806741000, 1901410000, 302366000, 401087000, 3052…</span></span>
<span><span class='c'>#&gt; $ CT_ID_10                &lt;dbl&gt; 25025140400, 25025120400, 25025030400, 25025010600…</span></span>
<span><span class='c'>#&gt; $ id                      &lt;int&gt; 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,…</span></span>
<span><span class='c'>#&gt; $ loc_name                &lt;chr&gt; "World", "World", "World", "World", "World", "Worl…</span></span>
<span><span class='c'>#&gt; $ status                  &lt;chr&gt; "M", "M", "M", "M", "M", "M", "M", "M", "M", "M", …</span></span>
<span><span class='c'>#&gt; $ score                   &lt;dbl&gt; 100.00, 100.00, 100.00, 100.00, 100.00, 100.00, 10…</span></span>
<span><span class='c'>#&gt; $ match_addr              &lt;chr&gt; "635 Hyde Park Avenue, Roslindale, Massachusetts, …</span></span>
<span><span class='c'>#&gt; $ long_label              &lt;chr&gt; "635 Hyde Park Avenue, Roslindale, MA, 02131, USA"…</span></span>
<span><span class='c'>#&gt; $ short_label             &lt;chr&gt; "635 Hyde Park Avenue", "660A Centre Street", "107…</span></span>
<span><span class='c'>#&gt; $ addr_type               &lt;chr&gt; "PointAddress", "PointAddress", "PointAddress", "P…</span></span>
<span><span class='c'>#&gt; $ type_field              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ place_name              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ place_addr              &lt;chr&gt; "635 Hyde Park Avenue, Roslindale, Massachusetts, …</span></span>
<span><span class='c'>#&gt; $ phone                   &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ url                     &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ rank                    &lt;dbl&gt; 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20…</span></span>
<span><span class='c'>#&gt; $ add_bldg                &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ add_num                 &lt;chr&gt; "635", "660A", "107", "138", "66", "23", "174", "2…</span></span>
<span><span class='c'>#&gt; $ add_num_from            &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ add_num_to              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ add_range               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ side                    &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ st_pre_dir              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ st_pre_type             &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ st_name                 &lt;chr&gt; "Hyde Park", "Centre", "Salem", "Saint James", "Ha…</span></span>
<span><span class='c'>#&gt; $ st_type                 &lt;chr&gt; "Avenue", "Street", "Street", "Avenue", "Avenue", …</span></span>
<span><span class='c'>#&gt; $ st_dir                  &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ bldg_type               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ bldg_name               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ level_type              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ level_name              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ unit_type               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ unit_name               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ sub_addr                &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ st_addr                 &lt;chr&gt; "635 Hyde Park Avenue", "660A Centre Street", "107…</span></span>
<span><span class='c'>#&gt; $ block                   &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ sector                  &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ nbrhd                   &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ district                &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ city                    &lt;chr&gt; "Roslindale", "Jamaica Plain", "Boston", "Boston",…</span></span>
<span><span class='c'>#&gt; $ metro_area              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ subregion               &lt;chr&gt; "Suffolk County", "Suffolk County", "Suffolk Count…</span></span>
<span><span class='c'>#&gt; $ region                  &lt;chr&gt; "Massachusetts", "Massachusetts", "Massachusetts",…</span></span>
<span><span class='c'>#&gt; $ region_abbr             &lt;chr&gt; "MA", "MA", "MA", "MA", "MA", "MA", "MA", "MA", "M…</span></span>
<span><span class='c'>#&gt; $ territory               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ zone                    &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ postal                  &lt;chr&gt; "02131", "02130", "02113", "02116", "02111", "0211…</span></span>
<span><span class='c'>#&gt; $ postal_ext              &lt;chr&gt; "4723", "2587", "2227", "5071", "1907", "2131", "2…</span></span>
<span><span class='c'>#&gt; $ country                 &lt;chr&gt; "USA", "USA", "USA", "USA", "USA", "USA", "USA", "…</span></span>
<span><span class='c'>#&gt; $ cntry_name              &lt;chr&gt; "United States", "United States", "United States",…</span></span>
<span><span class='c'>#&gt; $ lang_code               &lt;chr&gt; "ENG", "ENG", "ENG", "ENG", "ENG", "ENG", "ENG", "…</span></span>
<span><span class='c'>#&gt; $ distance                &lt;dbl&gt; 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,…</span></span>
<span><span class='c'>#&gt; $ x                       &lt;dbl&gt; -71.11927, -71.11409, -71.05552, -71.07630, -71.06…</span></span>
<span><span class='c'>#&gt; $ y                       &lt;dbl&gt; 42.27855, 42.31286, 42.36421, 42.34947, 42.35137, …</span></span>
<span><span class='c'>#&gt; $ display_x               &lt;dbl&gt; -71.11936, -71.11386, -71.05538, -71.07624, -71.06…</span></span>
<span><span class='c'>#&gt; $ display_y               &lt;dbl&gt; 42.27857, 42.31285, 42.36420, 42.34923, 42.35131, …</span></span>
<span><span class='c'>#&gt; $ xmin                    &lt;dbl&gt; -71.11936, -71.11486, -71.05538, -71.07624, -71.06…</span></span>
<span><span class='c'>#&gt; $ xmax                    &lt;dbl&gt; -71.11936, -71.11286, -71.05538, -71.07624, -71.06…</span></span>
<span><span class='c'>#&gt; $ ymin                    &lt;dbl&gt; 42.27857, 42.31185, 42.36420, 42.34923, 42.35031, …</span></span>
<span><span class='c'>#&gt; $ ymax                    &lt;dbl&gt; 42.27857, 42.31385, 42.36420, 42.34923, 42.35231, …</span></span>
<span><span class='c'>#&gt; $ ex_info                 &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ bldg_comp               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ struc_type              &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ struc_det               &lt;chr&gt; NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA…</span></span>
<span><span class='c'>#&gt; $ geometry                &lt;POINT [°]&gt; POINT (-71.11936 42.27857), POINT (-71.11386…</span></span></pre>
