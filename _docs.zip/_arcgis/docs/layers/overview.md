Overview
================

Layers represent represent a data service hosted by ArcGIS Online,
ArcGIS Enterprise, Platform, or even an ArcGIS Hub site. Layers are how
you will interact with your remotely hosted data.

The `{arcgis}` R metapackage is able to work with the most common types
of data services: feature services and image servers. The types of
layers that the R-ArcGIS Bridge does not yet support are vector and map
tile services.

## Types of services

When working with these data services, each service type is assigned
their own S3 class.

| Class | Description |
|----|----|
| `FeatureLayer` | Represents vector data. Can contain Point, MultiPoint, Polyline, or Polygon data |
| `Table` | A type of FeatureLayer in which there is no geometry present. Represents tabular data. |
| `ImageServer` | Provides access to raster imagery. |
| `FeatureServer` | A collection of FeatureLayer and Tables. |
| `GroupLayer` | A collection of FeatureLayer and Tables. |
| `MapServer` | A collection arbitrary data service types. |

## Accessing data services

The R package `{arcgislayers}` provides access to services. Working with
data services follows a pattern:

- first, create a reference to a remote data service
- query the data service and bring the results back into R

### Creating data service objects

Using `{arcgislayers}`, the function `arc_open()` will create a
reference to a service based on its url.

``` r
library(arcgis)

# feature service url
furl <- "https://services3.arcgis.com/ZvidGQkLaDJxRSJ2/arcgis/rest/services/PLACES_LocalData_for_BetterHealth/FeatureServer/4"

# feature layer
flayer <- arc_open(furl)
flayer
```

    #> <FeatureLayer>
    #> Name: ZCTAs
    #> Geometry Type: esriGeometryPolygon
    #> CRS: 3785
    #> Capabilities: Query,Extract

### Querying feature services

To bring data from the service into memory in R, you must use
`arc_select()`.

<div class="callout-tip">

Always bring as little data as possible into memory. Utilize the
`fields` and `where` arguments.

</div>

``` r
arc_select(
  flayer,
  where = "TotalPopulation > 100000",
  fields = c("objectid", "totalpopulation", "zcta5")
)
```

    #> Warning in CPL_crs_from_input(x): GDAL Message 1: CRS EPSG:3785 is deprecated. Its
    #> non-deprecated replacement EPSG:3857 will be used instead. To use the original CRS,
    #> set the OSR_USE_NON_DEPRECATED configuration option to NO.

    #> Simple feature collection with 23 features and 3 fields
    #> Geometry type: POLYGON
    #> Dimension:     XY
    #> Bounding box:  xmin: -13584740 ymin: 3464366 xmax: -8218961 ymax: 5130153
    #> Projected CRS: WGS 84 / Pseudo-Mercator
    #> First 10 features:
    #>    OBJECTID TotalPopulation ZCTA5                       geometry
    #> 1      2360          135256 08701 POLYGON ((-8266867 4879637,...
    #> 2      2529          103660 10467 POLYGON ((-8225100 4995955,...
    #> 3      2705          100330 11207 POLYGON ((-8228297 4966147,...
    #> 4      2706          101958 11208 POLYGON ((-8225296 4965937,...
    #> 5      2717          103447 11219 POLYGON ((-8239056 4957776,...
    #> 6      2718          105797 11220 POLYGON ((-8241925 4958752,...
    #> 7      2724          101727 11226 POLYGON ((-8234030 4960513,...
    #> 8      2733          100687 11236 POLYGON ((-8228926 4961495,...
    #> 9      2751          117110 11368 POLYGON ((-8223473 4976473,...
    #> 10     2755          105712 11373 POLYGON ((-8225601 4975030,...
