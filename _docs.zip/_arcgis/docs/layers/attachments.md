---
title: Working with Feature Layer Attachments
uid: attachments
---


# Working with Feature Layer Attachments

Feature services in ArcGIS Online and ArcGIS Enterprise can store attachments linked to individual features within their layers. This capability is commonly used in Survey123 forms where users upload photos, documents, or other files as part of their data collection. The R-ArcGIS Bridge provides three core functions for managing these attachments: querying metadata, downloading files, and updating attachments.

## Understanding Attachment Workflows

Before working with attachments, you need to establish a connection to your feature layer. This requires authentication if you’re accessing private services or plan to modify attachments. The typical workflow involves opening a layer reference, querying to understand what attachments exist, and then downloading or updating those files as needed.

## Querying Attachment Metadata

The `query_layer_attachments()` function retrieves metadata about attachments without downloading the actual files. This lets you inspect what attachments exist, their file names, sizes, and which features they belong to before committing to a download operation.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgisutils'>arcgisutils</a></span><span class='o'>)</span></span>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://developers.arcgis.com/r-bridge'>arcgislayers</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Authenticate if working with private data</span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/token.html'>set_arc_token</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/auth.html'>auth_user</a></span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Connect to your feature layer</span></span>
<span><span class='nv'>furl</span> <span class='o'>&lt;-</span> <span class='s'>"https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/rest/services/v8_Wide_Area_Search_Form_Feature_Layer___a2fe9c/FeatureServer/0"</span></span>
<span><span class='nv'>layer</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/arc_open.html'>arc_open</a></span><span class='o'>(</span><span class='nv'>furl</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Query all attachments in the layer</span></span>
<span><span class='nv'>att</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/attachments.html'>query_layer_attachments</a></span><span class='o'>(</span><span class='nv'>layer</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># preview the results</span></span>
<span><span class='nf'>dplyr</span><span class='nf'>::</span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>att</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 101</span></span>
<span><span class='c'>#&gt; Columns: 10</span></span>
<span><span class='c'>#&gt; $ parentGlobalId &lt;chr&gt; "51f34e57-003c-4cb5-b9c6-694c5bc63480", "ca558ac8-3377-…</span></span>
<span><span class='c'>#&gt; $ parentObjectId &lt;int&gt; 13, 14, 19, 21, 22, 27, 34, 35, 36, 40, 43, 49, 52, 53,…</span></span>
<span><span class='c'>#&gt; $ id             &lt;int&gt; 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,…</span></span>
<span><span class='c'>#&gt; $ globalId       &lt;chr&gt; "1646cbf2-b884-4b85-a8fa-6ce38dfe7474", "71bbbee7-0fd6-…</span></span>
<span><span class='c'>#&gt; $ name           &lt;chr&gt; "02d5cd1337d24bc699d6e1e55292c6d9.jpg", "049441602a4048…</span></span>
<span><span class='c'>#&gt; $ contentType    &lt;chr&gt; "image/jpeg", "image/jpeg", "image/jpeg", "image/jpeg",…</span></span>
<span><span class='c'>#&gt; $ size           &lt;int&gt; 401051, 87400, 179744, 250221, 211540, 152460, 155329, …</span></span>
<span><span class='c'>#&gt; $ keywords       &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "",…</span></span>
<span><span class='c'>#&gt; $ url            &lt;chr&gt; "https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/r…</span></span>
<span><span class='c'>#&gt; $ exifInfo       &lt;list&gt; [&lt;data.frame[4 x 2]&gt;], [&lt;data.frame[3 x 2]&gt;], [&lt;data.f…</span></span></pre>

The returned data frame contains columns like `PARENTOBJECTID` (which feature the attachment belongs to), `att_name` (the file name), and `id` (the attachment’s unique identifier). This metadata allows you to make informed decisions about which attachments to download.

## Filtering Attachments

You can filter attachments in two ways:

1.  by feature attributes or,
2.  by attachment properties.

Filtering by feature attributes is useful when you only want attachments from features meeting certain criteria, such as records flagged for follow-up.

The `definition_expression` argument accepts a standard SQL WHERE clause that is applied to the features in the feature service. This is akin to the `where` argument in [`arc_select()`](https://rdrr.io/pkg/arcgislayers/man/arc_select.html).

<pre class='chroma'>
<span><span class='c'># Filter based on **feature** attributes</span></span>
<span><span class='c'># Only get attachments where the followup_status field </span></span>
<span><span class='c'># is set to `"needs_followup"</span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/attachments.html'>query_layer_attachments</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>layer</span>, </span>
<span>  <span class='s'>"followup_status = 'needs_followup'"</span></span>
<span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; # A data frame: 24 × 10</span></span>
<span><span class='c'>#&gt;    parentGlobalId         parentObjectId    id globalId name  contentType   size</span></span>
<span><span class='c'>#&gt;  * &lt;chr&gt;                           &lt;int&gt; &lt;int&gt; &lt;chr&gt;    &lt;chr&gt; &lt;chr&gt;        &lt;int&gt;</span></span>
<span><span class='c'>#&gt;  1 498bb7fa-1b64-48b5-8c…             49    13 dd2afd9… 38f8… image/jpeg  272721</span></span>
<span><span class='c'>#&gt;  2 0b45291f-ec76-4ee1-91…             53    15 146c89e… 3f12… image/jpeg  289968</span></span>
<span><span class='c'>#&gt;  3 0b45291f-ec76-4ee1-91…             53    16 e929c75… 3f6c… image/jpeg  163008</span></span>
<span><span class='c'>#&gt;  4 0b45291f-ec76-4ee1-91…             53    17 54f1beb… 401c… image/jpeg  240901</span></span>
<span><span class='c'>#&gt;  5 edbe0c9f-f2a7-48b1-89…             69    23 482d4f6… 4f6f… image/jpeg  138262</span></span>
<span><span class='c'>#&gt;  6 e2d7ed7e-092a-4860-8d…             80    30 36fbdb2… 5c8a… image/jpeg  396238</span></span>
<span><span class='c'>#&gt;  7 5e059ee4-cbc7-4089-a8…             84    32 9e5cb7b… 669a… image/jpeg  411913</span></span>
<span><span class='c'>#&gt;  8 8823ae01-6799-4b74-ab…             86    33 2e807a4… 69a2… image/jpeg  344543</span></span>
<span><span class='c'>#&gt;  9 612edf09-92cd-4e39-8b…             91    36 c8981b5… 70ce… image/jpeg  368083</span></span>
<span><span class='c'>#&gt; 10 612edf09-92cd-4e39-8b…             91    37 1ff5060… 727b… image/jpeg  288994</span></span>
<span><span class='c'>#&gt; # ℹ 14 more rows</span></span>
<span><span class='c'>#&gt; # ℹ 3 more variables: keywords &lt;chr&gt;, url &lt;chr&gt;, exifInfo &lt;list&gt;</span></span></pre>

Alternatively, you can filter based on the properties of the attachment itself. To see what properties are available to query based on you can check the `attachmentProperties` element of the layer object.

<pre class='chroma'>
<span><span class='nv'>layer</span><span class='o'>$</span><span class='nv'>attachmentProperties</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt;          name          fieldName isEnabled</span></span>
<span><span class='c'>#&gt; 1          id       ATTACHMENTID      TRUE</span></span>
<span><span class='c'>#&gt; 2    globalId AttachmentGlobalID      TRUE</span></span>
<span><span class='c'>#&gt; 3        name           ATT_NAME      TRUE</span></span>
<span><span class='c'>#&gt; 4        size          DATA_SIZE      TRUE</span></span>
<span><span class='c'>#&gt; 5 contentType       CONTENT_TYPE      TRUE</span></span>
<span><span class='c'>#&gt; 6    keywords           Keywords      TRUE</span></span>
<span><span class='c'>#&gt; 7    exifInfo           ExifInfo      TRUE</span></span></pre>

This shows that we can query based on the `fieldName`s. To actually query based on these, we use the `attachments_definition_expression` argument which is applied to the attachment properties.

<pre class='chroma'>
<span><span class='c'># Filter based on attachment file names</span></span>
<span><span class='c'># Only get attachments from a specific date</span></span>
<span><span class='nv'>attachments</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/attachments.html'>query_layer_attachments</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>layer</span>,</span>
<span>  attachments_definition_expression <span class='o'>=</span> <span class='s'>"att_name like '%20221005%'"</span></span>
<span><span class='o'>)</span></span></pre>

## Downloading Attachments

Once you’ve identified the attachments you need, [`download_attachments()`](https://rdrr.io/pkg/arcgislayers/man/attachments.html) retrieves the actual files to your local system. The function takes the metadata from [`query_layer_attachments()`](https://rdrr.io/pkg/arcgislayers/man/attachments.html) and a destination folder, then downloads each file while preserving its original name.

<pre class='chroma'>
<span><span class='c'># Create a temporary directory for downloads</span></span>
<span><span class='nv'>tmp</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/file.path.html'>file.path</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/r/base/tempfile.html'>tempdir</a></span><span class='o'>(</span><span class='o'>)</span>, <span class='nf'>ulid</span><span class='nf'>::</span><span class='nf'><a href='https://rdrr.io/pkg/ulid/man/ulid.html'>ulid</a></span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span> </span>
<span></span>
<span><span class='c'># Create the directory if it doesn't exist</span></span>
<span><span class='nf'><a href='https://rdrr.io/r/base/files2.html'>dir.create</a></span><span class='o'>(</span><span class='nv'>tmp</span>, recursive <span class='o'>=</span> <span class='kc'>TRUE</span>, showWarnings <span class='o'>=</span> <span class='kc'>FALSE</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Download the queried attachments</span></span>
<span><span class='nv'>res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/attachments.html'>download_attachments</a></span><span class='o'>(</span><span class='nv'>attachments</span>, <span class='nv'>tmp</span>, .progress <span class='o'>=</span> <span class='kc'>FALSE</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Verify the downloads</span></span>
<span><span class='nv'>downloaded</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/list.files.html'>list.files</a></span><span class='o'>(</span><span class='nv'>tmp</span><span class='o'>)</span></span></pre>

The function returns a data frame showing the download results, including file paths and any errors encountered. This makes it easy to verify successful downloads and handle any issues that arose during the transfer.

## Updating Attachments

Updating attachments requires write access to the feature service, which typically means you need to own the service or have editing permissions granted by the owner. The update process involves uploading new attachment files and associating them with specific features using the [`update_attachments()`](https://rdrr.io/pkg/arcgislayers/man/update_attachments.html) function. This operation requires proper authentication through [`set_arc_token()`](https://rdrr.io/pkg/arcgisutils/man/token.html) before attempting any modifications.

In this example we will prepend the current date to the files. To do this, we will rename the files locally.

<pre class='chroma'>
<span><span class='c'># get today's date</span></span>
<span><span class='nv'>today</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/Sys.time.html'>Sys.Date</a></span><span class='o'>(</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># prepend attachments with the date</span></span>
<span><span class='nv'>new_filenames</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/paste.html'>paste0</a></span><span class='o'>(</span><span class='nv'>today</span>, <span class='s'>"-"</span>, <span class='nf'><a href='https://rdrr.io/r/base/basename.html'>basename</a></span><span class='o'>(</span><span class='nv'>attachments</span><span class='o'>$</span><span class='nv'>name</span><span class='o'>)</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># create new file paths</span></span>
<span><span class='nv'>new_fps</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/file.path.html'>file.path</a></span><span class='o'>(</span><span class='nv'>tmp</span>, <span class='nv'>new_filenames</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># the full name of downloaded attachments</span></span>
<span><span class='nv'>fps</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/file.path.html'>file.path</a></span><span class='o'>(</span><span class='nv'>tmp</span>, <span class='nv'>downloaded</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># rename the files</span></span>
<span><span class='nf'><a href='https://rdrr.io/r/base/files.html'>file.rename</a></span><span class='o'>(</span><span class='nv'>fps</span>, <span class='nv'>new_fps</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt;  [1] TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE</span></span>
<span><span class='c'>#&gt; [16] TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE</span></span></pre>

Now that we have renamed the files, we can use [`update_attachments()`](https://rdrr.io/pkg/arcgislayers/man/update_attachments.html) to update the attachments in the feature service.

<pre class='chroma'>
<span><span class='c'># update the attachments</span></span>
<span><span class='nv'>update_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/update_attachments.html'>update_attachments</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>layer</span>,</span>
<span>  <span class='c'># OID of the feature &lt;&gt; attachment relationship</span></span>
<span>  <span class='nv'>attachments</span><span class='o'>$</span><span class='nv'>parentObjectId</span>,</span>
<span>  <span class='c'># the attachment ID</span></span>
<span>  <span class='nv'>attachments</span><span class='o'>$</span><span class='nv'>id</span>,</span>
<span>  <span class='c'># the path to the attachment on disk</span></span>
<span>  <span class='nv'>new_fps</span>,</span>
<span>  <span class='c'># turn off for rmarkdown</span></span>
<span>  .progress <span class='o'>=</span> <span class='kc'>FALSE</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nf'><a href='https://rdrr.io/r/utils/head.html'>head</a></span><span class='o'>(</span><span class='nv'>update_res</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt;   objectId success</span></span>
<span><span class='c'>#&gt; 1       75    TRUE</span></span>
<span><span class='c'>#&gt; 2       76    TRUE</span></span>
<span><span class='c'>#&gt; 3       77    TRUE</span></span>
<span><span class='c'>#&gt; 4       78    TRUE</span></span>
<span><span class='c'>#&gt; 5       79    TRUE</span></span>
<span><span class='c'>#&gt; 6       80    TRUE</span></span></pre>

Similarly, we can undo our change just as easily!

<pre class='chroma'>
<span><span class='c'># rename the files again</span></span>
<span><span class='nf'><a href='https://rdrr.io/r/base/files.html'>file.rename</a></span><span class='o'>(</span><span class='nv'>new_fps</span>, <span class='nv'>fps</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt;  [1] TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE</span></span>
<span><span class='c'>#&gt; [16] TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE TRUE</span></span></pre>

<pre class='chroma'>
<span><span class='nv'>update_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/update_attachments.html'>update_attachments</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>layer</span>,</span>
<span>  <span class='nv'>attachments</span><span class='o'>$</span><span class='nv'>parentObjectId</span>,</span>
<span>  <span class='nv'>attachments</span><span class='o'>$</span><span class='nv'>id</span>,</span>
<span>  <span class='c'># using the previous filenames</span></span>
<span>  <span class='nv'>fps</span>,</span>
<span>  .progress <span class='o'>=</span> <span class='kc'>FALSE</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nf'><a href='https://rdrr.io/r/utils/head.html'>head</a></span><span class='o'>(</span><span class='nv'>update_res</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt;   objectId success</span></span>
<span><span class='c'>#&gt; 1       75    TRUE</span></span>
<span><span class='c'>#&gt; 2       76    TRUE</span></span>
<span><span class='c'>#&gt; 3       77    TRUE</span></span>
<span><span class='c'>#&gt; 4       78    TRUE</span></span>
<span><span class='c'>#&gt; 5       79    TRUE</span></span>
<span><span class='c'>#&gt; 6       80    TRUE</span></span></pre>
