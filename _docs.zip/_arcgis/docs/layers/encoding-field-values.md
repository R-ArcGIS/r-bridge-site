---
title: Encoding field values from domains
uid: encoding-field-values
---


# Encoding field values from domains

Domains are predefined lists of acceptable values for an attribute in a layer or feature service. Using domains can be helpful for enforcing data integrity and consistency by restricting the values that can be entered into a specific field. A domain consists of labels and corresponding codes. For example, in a hiking trails feature service, a `difficulty rating` field could use a domain with the following labels (and codes): Easy (`1`), Moderate (`2`), and Challenging (`3`). Learn more about [defining domain lists](https://doc.arcgis.com/en/arcgis-online/manage-data/define-attribute-lists-and-ranges.htm) in ArcGIS Online.

When querying a service, domain codes are returned by default, as these are the values that are stored in the service. But there may be times when the label is preferred, like when the data will be used for visualization or user-facing applications. By using `encode_field_values()` you can replace the codes with labels or add the labels as metadata, giving you flexible options for working with domain-based attributes.

The following example uses [a Living Atlas feature service](https://analysis-1.maps.arcgis.com/home/item.html?id=524770d249eb48b78c5280fc12b9b42b#overview) containing field office boundaries for Bureau of Land Management administrative units.

First, it’s helpful to take a look at the metadata for the feature service to understand which fields use domains:

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Feature service URL</span></span>
<span><span class='nv'>field_offices_url</span> <span class='o'>&lt;-</span> <span class='s'>"https://services2.arcgis.com/FiaPA4ga0iQKduv3/arcgis/rest/services/blm_natl_admu_field_poly_webpub_A_view/FeatureServer/0"</span></span>
<span></span>
<span><span class='c'># Create a connection to the feature service</span></span>
<span><span class='nv'>lyr</span> <span class='o'>&lt;-</span> <span class='nf'>arc_open</span><span class='o'>(</span><span class='nv'>field_offices_url</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Extract the domain info from the service metadata</span></span>
<span><span class='nv'>domain_info</span> <span class='o'>&lt;-</span> <span class='nv'>lyr</span><span class='o'>$</span><span class='nv'>fields</span><span class='o'>$</span><span class='nv'>domain</span></span>
<span></span>
<span><span class='c'># Preview domain values and codes for a field</span></span>
<span><span class='nf'><a href='https://rdrr.io/r/utils/head.html'>head</a></span><span class='o'>(</span><span class='nv'>domain_info</span><span class='o'>[[</span><span class='m'>8</span><span class='o'>]</span><span class='o'>]</span><span class='o'>$</span><span class='nv'>codedValues</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt;                                    name     code</span></span>
<span><span class='c'>#&gt; 1 CALIFORNIA, BUREAU OF LAND MANAGEMENT CA000000</span></span>
<span><span class='c'>#&gt; 2               STILLWATER FIELD OFFICE NVC01000</span></span>
<span><span class='c'>#&gt; 3                   BISHOP FIELD OFFICE CAC07000</span></span>
<span><span class='c'>#&gt; 4                SALT LAKE FIELD OFFICE UTW01000</span></span>
<span><span class='c'>#&gt; 5         ARIZONA STRIP DISTRICT OFFICE AZA00000</span></span>
<span><span class='c'>#&gt; 6             SOUTHWEST DISTRICT OFFICE COS00000</span></span></pre>
<pre class='chroma'>
<span><span class='c'># Read in data from the feature service</span></span>
<span><span class='nv'>res</span> <span class='o'>&lt;-</span> <span class='nf'>arc_select</span><span class='o'>(</span></span>
<span>  <span class='nv'>lyr</span>,</span>
<span>  fields <span class='o'>=</span> <span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='s'>"ADM_UNIT_CD"</span>, <span class='s'>"ADMIN_ST"</span><span class='o'>)</span>,</span>
<span><span class='o'>)</span></span>
<span><span class='nf'>dplyr</span><span class='nf'>::</span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>res</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 125</span></span>
<span><span class='c'>#&gt; Columns: 3</span></span>
<span><span class='c'>#&gt; $ ADM_UNIT_CD &lt;chr&gt; "NVB02000", "ORN04000", "CAN06000", "ORV04000", "UTW02000", "COF03000", "…</span></span>
<span><span class='c'>#&gt; $ ADMIN_ST    &lt;chr&gt; "NV", "OR", "CA", "OR", "UT", "CO", "WY", "MT", "OR", "NV", "NM", "NV", "…</span></span>
<span><span class='c'>#&gt; $ geometry    &lt;POLYGON [m]&gt; POLYGON ((-13094404 4727195..., POLYGON ((-13803788 5825015..., P…</span></span></pre>

## Replacing codes with domain labels

Above, we viewed some domain labels and codes for the administrative unit code field, `ADM_UNIT_CD`. Let’s replace the existing coded values with their corresponding labels for easier interpretation:

<pre class='chroma'>
<span><span class='c'># Replace the domain codes with labels</span></span>
<span><span class='nv'>offices_encoded</span> <span class='o'>&lt;-</span> <span class='nf'>encode_field_values</span><span class='o'>(</span><span class='nv'>res</span>, <span class='nv'>lyr</span>, field <span class='o'>=</span> <span class='s'>"ADM_UNIT_CD"</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Updated field values</span></span>
<span><span class='nf'>dplyr</span><span class='nf'>::</span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>offices_encoded</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 125</span></span>
<span><span class='c'>#&gt; Columns: 3</span></span>
<span><span class='c'>#&gt; $ ADM_UNIT_CD &lt;chr&gt; "TONOPAH FIELD OFFICE", "NW OREGON TILLAMOOK FIELD OFFICE", "REDDING FIEL…</span></span>
<span><span class='c'>#&gt; $ ADMIN_ST    &lt;chr&gt; "NV", "OR", "CA", "OR", "UT", "CO", "WY", "MT", "OR", "NV", "NM", "NV", "…</span></span>
<span><span class='c'>#&gt; $ geometry    &lt;POLYGON [m]&gt; POLYGON ((-13094404 4727195..., POLYGON ((-13803788 5825015..., P…</span></span></pre>

Replacing codes with descriptive labels can improve readability and make the data more suitable for display in maps or other user-facing applications.

## Adding domain labels as metadata

If you prefer to keep the original coded values and simply add the labels as metadata, this is possible using the `label` option, which assigns [`haven`](https://haven.tidyverse.org/reference/labelled.html) labels to each of the existing values. This option is useful for analysis workflows where both the code and label are needed.

Below, we add labels to the Administrative State Code field (`ADMIN_ST`):

<pre class='chroma'>
<span><span class='c'># Add domain labels</span></span>
<span><span class='nv'>offices_labelled</span> <span class='o'>&lt;-</span> <span class='nf'>encode_field_values</span><span class='o'>(</span><span class='nv'>res</span>, <span class='nv'>lyr</span>, field <span class='o'>=</span> <span class='s'>"ADMIN_ST"</span>, codes <span class='o'>=</span> <span class='s'>"label"</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Check the field</span></span>
<span><span class='nf'>haven</span><span class='nf'>::</span><span class='nf'><a href='https://haven.tidyverse.org/reference/labelled.html'>is.labelled</a></span><span class='o'>(</span><span class='nv'>offices_labelled</span><span class='o'>$</span><span class='nv'>ADMIN_ST</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; [1] TRUE</span></span></pre>
<pre class='chroma'>
<span><span class='c'># View labels</span></span>
<span><span class='nf'>labelled</span><span class='nf'>::</span><span class='nf'><a href='https://larmarange.github.io/labelled/reference/val_labels.html'>val_labels</a></span><span class='o'>(</span><span class='nv'>offices_labelled</span><span class='o'>$</span><span class='nv'>ADMIN_ST</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt;         Alaska        Arizona     California       Colorado Eastern States          Idaho </span></span>
<span><span class='c'>#&gt;           "AK"           "AZ"           "CA"           "CO"           "ES"           "ID" </span></span>
<span><span class='c'>#&gt;        Montana     New Mexico         Nevada         Oregon           Utah        Wyoming </span></span>
<span><span class='c'>#&gt;           "MT"           "NM"           "NV"           "OR"           "UT"           "WY"</span></span></pre>

This approach preserves the original data structure while enhancing interpretability for downstream analysis.
