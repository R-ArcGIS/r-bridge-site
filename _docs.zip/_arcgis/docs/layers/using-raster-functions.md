---
title: Using raster functions
uid: using-raster-functions
---


# Using raster functions

Raster functions are server-side operations that can be applied to imagery and raster data to perform analysis, visualization, and data transformation. These functions are made available through ArcGIS ImageServers and allow you to process raster data dynamically without downloading large datasets to your local machine.

In this tutorial, we’ll demonstrate how to discover and apply raster functions using the [Forest Service FIA BIGMAP Tree Species Aboveground Biomass](https://data.fs.usda.gov/geodata/rastergateway/bigmap/index.php) dataset, which represents estimates in tons per acre for total aboveground biomass as well as that of 327 individual tree species at a 30 meter pixel spatial resolution within the coterminous United States.

## Connecting to an ImageServer

First, we’ll establish a connection to the ImageServer containing our biomass data:

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># Store the ImageServer URL</span></span>
<span><span class='nv'>tree_species_biomass</span> <span class='o'>&lt;-</span> <span class='s'>"https://di-usfsdata.img.arcgis.com/arcgis/rest/services/FIA_BIGMAP_2018_Tree_Species_Aboveground_Biomass/ImageServer"</span></span>
<span></span>
<span><span class='c'># Create a connection to the ImageServer</span></span>
<span><span class='nv'>srvr</span> <span class='o'>&lt;-</span> <span class='nf'>arc_open</span><span class='o'>(</span><span class='nv'>tree_species_biomass</span><span class='o'>)</span></span>
<span><span class='nv'>srvr</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; &lt;ImageServer &lt;1 bands, 27 fields&gt;&gt;</span></span>
<span><span class='c'>#&gt; Name: FIA_BIGMAP_2018_Tree_Species_Aboveground_Biomass</span></span>
<span><span class='c'>#&gt; Description: null</span></span>
<span><span class='c'>#&gt; Extent: -2911620 2933940 164760 3254760 (xmin, xmax, ymin, ymax)</span></span>
<span><span class='c'>#&gt; Resolution: 30 x 30</span></span>
<span><span class='c'>#&gt; CRS: 102039</span></span>
<span><span class='c'>#&gt; Capabilities: Image,Metadata,Catalog,Mensuration</span></span></pre>

## Discovering Available Raster Functions

Once connected, we can explore what raster functions are available on this ImageServer:

<pre class='chroma'>
<span><span class='c'># List all raster functions available in the ImageServer</span></span>
<span><span class='nv'>raster_fns</span> <span class='o'>&lt;-</span> <span class='nf'>list_raster_fns</span><span class='o'>(</span><span class='nv'>srvr</span><span class='o'>)</span></span>
<span><span class='nv'>raster_fns</span> </span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; # A data frame: 327 × 3</span></span>
<span><span class='c'>#&gt;    name                       description                                                 help </span></span>
<span><span class='c'>#&gt;  * &lt;chr&gt;                      &lt;chr&gt;                                                       &lt;chr&gt;</span></span>
<span><span class='c'>#&gt;  1 SPCD_0000_TOTAL            TOTAL                                                       &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  2 None                       Make a Raster or Raster Dataset into a Function Raster Dat… &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  3 SPCD_0010_Abies_spp.       fir spp.                                                    &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  4 SPCD_0012_Abies_balsamea   balsam fir                                                  &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  5 SPCD_0015_Abies_concolor   white fir                                                   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  6 SPCD_0016_Abies_fraseri    Fraser fir                                                  &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  7 SPCD_0017_Abies_grandis    grand fir                                                   &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  8 SPCD_0018_Abies_lasiocarpa corkbark fir                                                &lt;NA&gt; </span></span>
<span><span class='c'>#&gt;  9 SPCD_0019_Abies_lasiocarpa subalpine fir                                               &lt;NA&gt; </span></span>
<span><span class='c'>#&gt; 10 SPCD_0020_Abies_magnifica  California red fir                                          &lt;NA&gt; </span></span>
<span><span class='c'>#&gt; # ℹ 317 more rows</span></span></pre>

The `list_raster_fns()` function returns a data frame containing all available raster functions. Each function corresponds to a different tree species or analysis type available in the dataset.

## Applying Raster Functions

To apply a raster function, specify its name in the `raster_fn` argument when calling `arc_raster()`. Here we’ll extract biomass data for Balsam Fir trees in a specific geographic area:

<pre class='chroma'>
<span><span class='c'># Fetch data with the Balsam Fir raster function applied</span></span>
<span><span class='nv'>res</span> <span class='o'>&lt;-</span> <span class='nf'>arc_raster</span><span class='o'>(</span></span>
<span>  <span class='nv'>srvr</span>,</span>
<span>  xmin <span class='o'>=</span> <span class='o'>-</span><span class='m'>71</span>,</span>
<span>  xmax <span class='o'>=</span> <span class='o'>-</span><span class='m'>67</span>,</span>
<span>  ymin <span class='o'>=</span> <span class='m'>43</span>,</span>
<span>  ymax <span class='o'>=</span> <span class='m'>47.5</span>,</span>
<span>  bbox_crs <span class='o'>=</span> <span class='m'>4326</span>,</span>
<span>  width <span class='o'>=</span> <span class='m'>1000</span>,</span>
<span>  height <span class='o'>=</span> <span class='m'>1000</span>,</span>
<span>  raster_fn <span class='o'>=</span> <span class='s'>"SPCD_0012_Abies_balsamea"</span></span>
<span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Warning in CPL_crs_from_input(x): GDAL Message 1: EPSG:102039 is not a valid CRS code, but</span></span>
<span><span class='c'>#&gt; ESRI:102039 is. Assuming ESRI:102039 was meant</span></span></pre>
<pre class='chroma'>
<span><span class='c'># Visualize the results</span></span>
<span><span class='nf'>terra</span><span class='nf'>::</span><span class='nf'><a href='https://rspatial.github.io/terra/reference/plot.html'>plot</a></span><span class='o'>(</span><span class='nv'>res</span><span class='o'>)</span></span></pre>

![](C:/Users/mar10556/AppData/Local/Temp/1/RtmpkN6sGR/file47f47d8a4cce_files/figure-gfm/unnamed-chunk-4-1.png)<!-- -->

<img src="../shared/images/rasterfn-balsamfir.png" style="width:70.0%" />

The resulting `SpatRaster` object contains the processed biomass values for Balsam Fir trees in our specified extent. The raster function has been applied server-side, returning only the processed data we need for analysis.
