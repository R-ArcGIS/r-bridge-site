---
title: Publishing services
uid: publishing-services
subtitle: Create Hosted ArcGIS Online or Enterprise Feature Services from R
freeze: TRUE
---


# Publishing services

In addition to consuming data as an R user, you may also want to publish data as a hosted feature service. In this tutorial, you will learn how to publish an `sf` object <!-- or a `data.frame`--> to ArcGIS Online or Enterprise.

## Authorization

In order to publish content to ArcGIS Online or Enterprise, you must first obtain an access token permitting you to do so.

<div class="callout-caution">

If you have not yet set up your R environment for authorization, see [**Authorize with your Portal**](/authentication/connecting-to-a-portal). Ensure that the environment variables `ARCGIS_CLIENT` and `ARCGIS_USER` are set at minimum. If you are using ArcGIS Enterprise, ensure that `ARCGIS_HOST` is properly set as well.

</div>

Go through the following code flow to set your credentials.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>token</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/auth.html'>auth_code</a></span><span class='o'>(</span><span class='o'>)</span>  <span class='c'># &lt;1&gt;</span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/token.html'>set_arc_token</a></span><span class='o'>(</span><span class='nv'>token</span><span class='o'>)</span> <span class='c'># &lt;2&gt;</span></span></pre>

1.  Create an access token
2.  Set it to an environment variable.

Now that you have authorized to your Portal, you will be able to publish content.

## Publishing {sf} objects

To publish an [sf](https://r-spatial.github.io/sf/) object to your portal, you can use the function `publish_layer()`. The publishing process requires you to add an item to your portal and publish it. The `publish_layer()` function handles these steps for you.

First, read in the [North Carolina SIDS](https://cran.r-project.org/web/packages/spdep/vignettes/sids.html) dataset that comes packaged with `sf` and store it in an object called `nc`.

<pre class='chroma'>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'>sf</span><span class='nf'>::</span><span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_read.html'>read_sf</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/r/base/system.file.html'>system.file</a></span><span class='o'>(</span><span class='s'>"shape/nc.shp"</span>, package <span class='o'>=</span> <span class='s'>"sf"</span><span class='o'>)</span><span class='o'>)</span></span>
<span><span class='nv'>nc</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 100 features and 14 fields</span></span>
<span><span class='c'>#&gt; Geometry type: MULTIPOLYGON</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -84.32385 ymin: 33.88199 xmax: -75.45698 ymax: 36.58965</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  NAD27</span></span>
<span><span class='c'>#&gt; # A tibble: 100 × 15</span></span>
<span><span class='c'>#&gt;     AREA PERIMETER CNTY_ CNTY_ID NAME     FIPS  FIPSNO CRESS_ID BIR74 SID74 NWBIR74 BIR79 SID79</span></span>
<span><span class='c'>#&gt;    &lt;dbl&gt;     &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt; &lt;chr&gt;    &lt;chr&gt;  &lt;dbl&gt;    &lt;int&gt; &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt; &lt;dbl&gt; &lt;dbl&gt;</span></span>
<span><span class='c'>#&gt;  1 0.114      1.44  1825    1825 Ashe     37009  37009        5  1091     1      10  1364     0</span></span>
<span><span class='c'>#&gt;  2 0.061      1.23  1827    1827 Allegha… 37005  37005        3   487     0      10   542     3</span></span>
<span><span class='c'>#&gt;  3 0.143      1.63  1828    1828 Surry    37171  37171       86  3188     5     208  3616     6</span></span>
<span><span class='c'>#&gt;  4 0.07       2.97  1831    1831 Curritu… 37053  37053       27   508     1     123   830     2</span></span>
<span><span class='c'>#&gt;  5 0.153      2.21  1832    1832 Northam… 37131  37131       66  1421     9    1066  1606     3</span></span>
<span><span class='c'>#&gt;  6 0.097      1.67  1833    1833 Hertford 37091  37091       46  1452     7     954  1838     5</span></span>
<span><span class='c'>#&gt;  7 0.062      1.55  1834    1834 Camden   37029  37029       15   286     0     115   350     2</span></span>
<span><span class='c'>#&gt;  8 0.091      1.28  1835    1835 Gates    37073  37073       37   420     0     254   594     2</span></span>
<span><span class='c'>#&gt;  9 0.118      1.42  1836    1836 Warren   37185  37185       93   968     4     748  1190     2</span></span>
<span><span class='c'>#&gt; 10 0.124      1.43  1837    1837 Stokes   37169  37169       85  1612     1     160  2038     5</span></span>
<span><span class='c'>#&gt; # ℹ 90 more rows</span></span>
<span><span class='c'>#&gt; # ℹ 2 more variables: NWBIR79 &lt;dbl&gt;, geometry &lt;MULTIPOLYGON [°]&gt;</span></span></pre>

Now that you have an `sf` object and you have authorized with your portal, all that’s left is to publish the item!

`publish_layer()` has only two required arguments:

- `x` the `sf` object or `data.frame`
- `title` the title of layer you are creating

<pre class='chroma'>
<span><span class='nv'>res</span> <span class='o'>&lt;-</span> <span class='nf'>publish_layer</span><span class='o'>(</span><span class='nv'>nc</span>, <span class='s'>"North Carolina SIDS"</span><span class='o'>)</span></span>
<span><span class='nv'>res</span></span>
<span><span class='c'>#&gt; $services</span></span>
<span><span class='c'>#&gt;              type</span></span>
<span><span class='c'>#&gt; 1 Feature Service</span></span>
<span><span class='c'>#&gt;                                                                                             serviceurl</span></span>
<span><span class='c'>#&gt; 1 https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/rest/services/North Carolina SIDS/FeatureServer</span></span>
<span><span class='c'>#&gt;     size                                jobId                    serviceItemId</span></span>
<span><span class='c'>#&gt; 1 125766 f14451a7-325b-40b0-85c3-534bcf122806 32511ce0413f40d08303e267a7093be0</span></span>
<span><span class='c'>#&gt;                                                                                          encodedServiceURL</span></span>
<span><span class='c'>#&gt; 1 https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/rest/services/North%20Carolina%20SIDS/FeatureServer</span></span></pre>
<div class="callout-warning">

If you encounter errors while publishing, try using a feature layer title that does not contain spaces or special characters, such as “NorthCarolinaSIDS” for this example.

</div>

Now from your Portal’s [Content page](https://arcgis.com/home/content.html) you should see two items associated with your feature service:

<img src="../shared/images/published-items.png" style="width:70.0%" />

Behind the scenes, `publish_layer()` added the `sf` object as a *Feature Layer* item first and then published this item as a *Feature Layer (hosted)*. After publishing, you will typically only interact with the hosted feature layer. (Note that the dependency between these two items prevents you from deleting the underlying feature layer while the hosted feature layer still exists.)

Click **View details** on the hosted feature layer item and you should see something like the below:

<img src="../shared/images/nc-sids.png" style="width:70.0%" />

## Reading the published Feature Layer

The output of the `publish_layer()` function is a list that contains information about where the `sf` object was published. You can retrieve the `encodedServiceUrl` from the response and use `arc_open()` to return the metadata for your newly-created service.

<pre class='chroma'>
<span><span class='nv'>nc_fserver</span> <span class='o'>&lt;-</span> <span class='nf'>arc_open</span><span class='o'>(</span><span class='nv'>res</span><span class='o'>[[</span><span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='s'>"services"</span>, <span class='s'>"encodedServiceURL"</span><span class='o'>)</span><span class='o'>]</span><span class='o'>]</span><span class='o'>)</span></span>
<span><span class='nv'>nc_fserver</span></span>
<span><span class='c'>#&gt; &lt;FeatureServer &lt;1 layer, 0 tables&gt;&gt;</span></span>
<span><span class='c'>#&gt; CRS: 4267</span></span>
<span><span class='c'>#&gt; Capabilities: Create,Delete,Query,Update,Editing</span></span>
<span><span class='c'>#&gt;   0: North Carolina SIDS (esriGeometryPolygon)</span></span></pre>

You’ll notice that this is a `FeatureServer`. All items that are published to a Portal become their own Feature Server with a single `FeatureLayer`.

You can extract a single layer from the `FeatureServer` using `get_layer()`. Provide the `FeatureServer` as the first argument and then the ID of the layer you want as the second argument.

<pre class='chroma'>
<span><span class='nf'>get_layer</span><span class='o'>(</span><span class='nv'>nc_fserver</span>, <span class='m'>0</span><span class='o'>)</span></span>
<span><span class='c'>#&gt; &lt;FeatureLayer&gt;</span></span>
<span><span class='c'>#&gt; Name: North Carolina SIDS</span></span>
<span><span class='c'>#&gt; Geometry Type: esriGeometryPolygon</span></span>
<span><span class='c'>#&gt; CRS: 4267</span></span>
<span><span class='c'>#&gt; Capabilities: Create,Delete,Query,Update,Editing</span></span></pre>

## Publishing `data.frame`s

Publishing a `data.frame` follows the same steps as those above. The difference is that it creates a `Table` object. Try repeating the same process but using the palmerpenguins dataset!

<pre class='chroma'>
<span><span class='c'># install.packages("palmerpenguins")</span></span>
<span><span class='nf'>palmerpenguins</span><span class='nf'>::</span><span class='nv'>penguins</span></span></pre>
<div class="callout-tip" title="Solution" collapse="true">

<pre class='chroma'>
<span><span class='nf'>publish_layer</span><span class='o'>(</span><span class='nf'>palmerpenguins</span><span class='nf'>::</span><span class='nv'>penguins</span>, <span class='s'>"Palmer Penguins"</span><span class='o'>)</span></span></pre>
</div>
