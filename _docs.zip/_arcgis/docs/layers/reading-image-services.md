---
title: Reading image services
uid: reading-image-services
freeze: TRUE
---


# Reading image services

ArcGIS Online and Enterprise web services can easily be read into R using [arcgislayers](https://developers.arcgis.com/r-bridge). Supported service types include:

- [FeatureServer](https://developers.arcgis.com/rest/services-reference/enterprise/feature-service.htm)
  - [FeatureLayer](https://developers.arcgis.com/rest/services-reference/enterprise/feature-layer.htm)
  - [Table](https://developers.arcgis.com/rest/services-reference/enterprise/feature-layer.htm)
- [MapServer](https://developers.arcgis.com/rest/services-reference/enterprise/map-service.htm)
  - [GroupLayer](https://developers.arcgis.com/web-map-specification/objects/groupLayer/)
- [ImageServer](https://developers.arcgis.com/rest/services-reference/enterprise/image-service.htm)

Metadata for all of the above service types can be accessed using `arc_open()`. Feature data can be read in using `arc_select()` for FeatureLayer, Table, and ImageServer.

This tutorial will teach you the basics of reading data from hosted image services into R as [`{terra} SpatRaster`](https://rspatial.github.io/terra/reference/rast.html) objects using [arcgislayers](https://developers.arcgis.com/r-bridge). The source for an image service is published raster or imagery data. To learn more about image services, see the [Image services documentation](https://enterprise.arcgis.com/en/server/latest/publish-services/windows/key-concepts-for-image-services.htm).

<div class="callout-note">

When leveraging Esri hosted content, organizations should review the [ArcGIS Online terms of use](https://doc.arcgis.com/en/arcgis-online/reference/terms-of-use.htm), as well as the terms of use for the data layer to ensure they are in compliance with extracting data and/or making it available in other systems.

</div>

## Objective

The objective of this tutorial is to teach you how to:

- find a image service url from ArcGIS Online
- read in the data from the image service
- filter the image service by a bounding box
- use `terra` for viewing and writing

## Obtaining an image service url

For this example, you will read in multispectral Landsat imagery of the Ouarkziz Crater from ArcGIS Online.

You will use the functions `arc_open()` and `arc_raster()` to read image data from ArcGIS Online into R. However, these functions require the url of the hosted image service. To find this, navigate to the [item](https://www.arcgis.com/home/item.html?id=d9b466d6a9e647ce8d1dd5fe12eb434b) in ArcGIS Online.

<img src="../shared/images/multispectral-landsat.png" style="width:70.0%" />

When you scroll down, on the right hand side, you will see a button to view the service itself.

<img src="../shared/images/view-url-imagery.png"
style="width:45.0%" />

Clicking this will bring you to the Image Service, where you can more closely investigate the metadata and supported operations for this service. Navigate to your browser’s search bar and copy the url.

    https://landsat2.arcgis.com/arcgis/rest/services/Landsat/MS/ImageServer

## Opening an Image Service

First, load the `arcgis` R package. If you do not have `arcgis` installed, install it with `pak::pak("r-arcgis/arcgis")` or `install.packages("arcgis")`.

<div class="aside">

[pak](https://pak.r-lib.org/) is an R package that makes it faster and easier to install R packages. If you do not have it installed, run `install.packages("pak")` first.

</div>

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span></pre>

Use the below code to store the image service url in an object called `url`.

<pre class='chroma'>
<span><span class='nv'>url</span> <span class='o'>&lt;-</span> <span class='s'>"https://landsat2.arcgis.com/arcgis/rest/services/Landsat/MS/ImageServer"</span></span></pre>

Then pass this variable to `arc_open()` and save it to `imgsrv` (image service).

<pre class='chroma'>
<span><span class='nv'>imgsrv</span> <span class='o'>&lt;-</span> <span class='nf'>arc_open</span><span class='o'>(</span><span class='nv'>url</span><span class='o'>)</span></span>
<span><span class='nv'>imgsrv</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; &lt;ImageServer &lt;11 bands, 26 fields&gt;&gt;</span></span>
<span><span class='c'>#&gt; Name: Landsat/MS</span></span>
<span><span class='c'>#&gt; Description: Multispectral Landsat image service covering the landmass of the World. This serv</span></span>
<span><span class='c'>#&gt; Extent: -20037507.07 20037507.84 -9694091.07 9691188.93 (xmin, xmax, ymin, ymax)</span></span>
<span><span class='c'>#&gt; Resolution: 30 x 30</span></span>
<span><span class='c'>#&gt; CRS: 3857</span></span>
<span><span class='c'>#&gt; Capabilities: Catalog,Image,Metadata</span></span></pre>

`arc_open()` will create a `ImageServer` object. Under the hood, this is really just a list containing the image service’s metadata.

<div class="callout-note" collapse="true"
title="ImageServer details for the curious">

The `ImageServer` object is obtained by adding `?f=json` to the image server url and processing the json. All of the metadata is stored in the `ImageServer` object. You can see this by running `unclass(imgsrv)`. Be warned! It gets messy.

</div>

With this `ImageServer` object, you can read data from the service into R!

## Reading from a Image Service

Once you have a `ImageServer` object, you can access the image data using the `arc_raster()` function. Pass the coordinates for a bounding box into the function using the `xmin`, `ymin`, `xmax`, and `ymax` arguments. Store the results of `arc_raster()` in the object `crater`.

<div class="callout-warning">

Avoid reading in more data than you need! When extracting data from an image service, it is best practice to include a bounding box to limit the extraction to just the area that you need. Make sure to provide the bounding box coordinates in the Coordinate Reference System (CRS) of the image service or use the `bbox_crs` argument to specify another CRS for these coordinates.

</div>

<pre class='chroma'>
<span><span class='nv'>crater</span> <span class='o'>&lt;-</span> <span class='nf'>arc_raster</span><span class='o'>(</span></span>
<span>  <span class='nv'>imgsrv</span>,</span>
<span>  xmin <span class='o'>=</span> <span class='o'>-</span><span class='m'>846028</span>,</span>
<span>  ymin <span class='o'>=</span> <span class='m'>3373101</span>,</span>
<span>  xmax <span class='o'>=</span> <span class='o'>-</span><span class='m'>833783</span>,</span>
<span>  ymax <span class='o'>=</span> <span class='m'>3380738</span></span>
<span><span class='o'>)</span></span>
<span><span class='nv'>crater</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; class       : SpatRaster </span></span>
<span><span class='c'>#&gt; size        : 400, 400, 11  (nrow, ncol, nlyr)</span></span>
<span><span class='c'>#&gt; resolution  : 30.6125, 30.6125  (x, y)</span></span>
<span><span class='c'>#&gt; extent      : -846028, -833783, 3370797, 3383042  (xmin, xmax, ymin, ymax)</span></span>
<span><span class='c'>#&gt; coord. ref. : WGS 84 / Pseudo-Mercator (EPSG:3857) </span></span>
<span><span class='c'>#&gt; source      : file47f472866ff9.tiff </span></span>
<span><span class='c'>#&gt; names       : Coast~rosol, Blue, Green, Red, NearInfrared, Short~red_1, ...</span></span></pre>

The result is a `SpatRaster` object that you can now work with using **`terra`** and any other R packages.

### Using `terra`

From here, you can pursue your own raster and imagery workflows using `terra`. For some simple examples, consider plotting the image:

<pre class='chroma'>
<span><span class='nf'>terra</span><span class='nf'>::</span><span class='nf'><a href='https://rspatial.github.io/terra/reference/plotRGB.html'>plotRGB</a></span><span class='o'>(</span><span class='nv'>crater</span>, stretch <span class='o'>=</span> <span class='s'>"lin"</span><span class='o'>)</span></span></pre>
<img src="../shared/images/ouarkziz-crater-RGB.png" style="width:70.0%" />

or saving the image locally:

<pre class='chroma'>
<span><span class='nf'>terra</span><span class='nf'>::</span><span class='nf'><a href='https://rspatial.github.io/terra/reference/writeRaster.html'>writeRaster</a></span><span class='o'>(</span><span class='nv'>crater</span>, <span class='s'>"ouarkziz-crater-RGB.tif"</span>, overwrite <span class='o'>=</span> <span class='kc'>TRUE</span><span class='o'>)</span></span></pre>
