---
title: Adding fields to feature services
uid: adding-fields
---


# Adding fields to feature services

This tutorial demonstrates how to add new fields to an existing feature service using R. Adding fields allows you to expand your published data without creating an entirely new service.

## Prerequisites and Permissions

To add fields to a feature service, you must be either the service owner or have administrative privileges. This is a potentially destructive operation, so proceed with caution and consider testing on non-production data first.

## Common Use Cases

Adding fields to existing feature services is useful when you need to:

- Extend a published feature service with additional data columns
- Add model predictions or calculated scores to existing spatial data
- Incorporate new attributes discovered after initial publication
- Append analytical results without republishing the entire dataset

## Authentication Setup

Before beginning, you’ll need to authenticate to ArcGIS Online or ArcGIS Enterprise. For detailed authentication approaches, see the [authentication guide](https://developers.arcgis.com/r-bridge/authentication/connecting-to-a-portal/).

This tutorial uses the Palmer Penguins dataset as an example. We’ll initially publish the data without the `body_mass` field, then demonstrate how to add it later. For more comprehensive publishing guidance, refer to the [publishing tutorial](https://developers.arcgis.com/r-bridge/layers/publishing/).

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span>
<span><span class='nf'>set_arc_token</span><span class='o'>(</span><span class='nf'>auth_user</span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span></pre>

## Publishing the Initial Dataset

We’ll start by publishing the penguins dataset with all columns except `body_mass`, which we’ll add later to demonstrate the field addition process:

<pre class='chroma'>
<span><span class='c'># create a random unique name for publishing</span></span>
<span><span class='nv'>layer_name</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/paste.html'>paste0</a></span><span class='o'>(</span><span class='s'>"penguins-"</span>, <span class='nf'>ulid</span><span class='nf'>::</span><span class='nf'><a href='https://rdrr.io/pkg/ulid/man/ulid.html'>ulid</a></span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># subset to all but body mass</span></span>
<span><span class='nv'>to_publish</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/subset.html'>subset</a></span><span class='o'>(</span><span class='nv'>penguins</span>, select <span class='o'>=</span> <span class='o'>-</span><span class='nv'>body_mass</span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># publish a layer</span></span>
<span><span class='nv'>published</span> <span class='o'>&lt;-</span> <span class='nf'>publish_layer</span><span class='o'>(</span><span class='nv'>to_publish</span>, <span class='nv'>layer_name</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='nv'>new_service_url</span> <span class='o'>&lt;-</span> <span class='nv'>published</span><span class='o'>$</span><span class='nv'>services</span><span class='o'>$</span><span class='nv'>encodedServiceURL</span></span>
<span></span>
<span><span class='nv'>penguins_fl</span> <span class='o'>&lt;-</span> <span class='nf'>arc_open</span><span class='o'>(</span><span class='nv'>new_service_url</span><span class='o'>)</span> <span class='o'>|&gt;</span></span>
<span>  <span class='nf'>get_layer</span><span class='o'>(</span><span class='m'>0</span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>penguins_fl</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; &lt;Table&gt;</span></span>
<span><span class='c'>#&gt; Name: penguins-01K705HWVTR051KD17RKT2H08G</span></span>
<span><span class='c'>#&gt; Capabilities: Create,Delete,Query,Update,Editing</span></span></pre>

## Adding New Fields to the Service Definition

Now we’ll add the missing `body_mass` field to our published feature service. The service definition contains metadata that describes the service structure, including fields, symbology, and indexes.

### Defining Field Types

First, we need to define the field structure for the new column. The [`arcgisutils::as_fields()`](https://rdrr.io/pkg/arcgisutils/man/field_mapping.html) function automatically infers appropriate field types from your R data:

<pre class='chroma'>
<span><span class='nv'>field_types</span> <span class='o'>&lt;-</span> <span class='nf'>as_fields</span><span class='o'>(</span><span class='nv'>penguins</span><span class='o'>[</span>,<span class='s'>"body_mass"</span>, drop <span class='o'>=</span> <span class='kc'>FALSE</span><span class='o'>]</span><span class='o'>)</span></span>
<span><span class='nv'>field_types</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt;              name                 type     alias length nullable editable</span></span>
<span><span class='c'>#&gt; integer body_mass esriFieldTypeInteger body_mass     NA     TRUE     TRUE</span></span></pre>

**Important**: Only include the new fields you want to add. Including existing field names will cause an error since fields cannot be duplicated in the service definition.

### Updating the Service Definition

Use [`arcgislayers::add_layer_definition()`](https://rdrr.io/pkg/arcgislayers/man/definition.html) to add the new field to the feature service. This function updates the service schema and returns the modified feature layer:

<pre class='chroma'>
<span><span class='c'># update the feature service definition</span></span>
<span><span class='nv'>penguins_fl</span> <span class='o'>&lt;-</span> <span class='nf'>add_layer_definition</span><span class='o'>(</span></span>
<span>  <span class='nv'>penguins_fl</span>, </span>
<span>  fields <span class='o'>=</span> <span class='nv'>field_types</span></span>
<span><span class='o'>)</span></span></pre>

### Verifying the New Field

Let’s confirm that our new field has been successfully added to the feature service:

<pre class='chroma'>
<span><span class='nf'>list_fields</span><span class='o'>(</span><span class='nv'>penguins_fl</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; # A data frame: 9 × 10</span></span>
<span><span class='c'>#&gt;   name        type        actualType alias sqlType nullable editable domain defaultValue length</span></span>
<span><span class='c'>#&gt; * &lt;chr&gt;       &lt;chr&gt;       &lt;chr&gt;      &lt;chr&gt; &lt;chr&gt;   &lt;lgl&gt;    &lt;lgl&gt;    &lt;lgl&gt;  &lt;lgl&gt;         &lt;int&gt;</span></span>
<span><span class='c'>#&gt; 1 object_id   esriFieldT… int        obje… sqlTyp… FALSE    FALSE    NA     NA               NA</span></span>
<span><span class='c'>#&gt; 2 species     esriFieldT… nvarchar   spec… sqlTyp… TRUE     TRUE     NA     NA              255</span></span>
<span><span class='c'>#&gt; 3 island      esriFieldT… nvarchar   isla… sqlTyp… TRUE     TRUE     NA     NA              255</span></span>
<span><span class='c'>#&gt; 4 bill_len    esriFieldT… float      bill… sqlTyp… TRUE     TRUE     NA     NA               NA</span></span>
<span><span class='c'>#&gt; 5 bill_dep    esriFieldT… float      bill… sqlTyp… TRUE     TRUE     NA     NA               NA</span></span>
<span><span class='c'>#&gt; 6 flipper_len esriFieldT… int        flip… sqlTyp… TRUE     TRUE     NA     NA               NA</span></span>
<span><span class='c'>#&gt; 7 sex         esriFieldT… nvarchar   sex   sqlTyp… TRUE     TRUE     NA     NA              255</span></span>
<span><span class='c'>#&gt; 8 year        esriFieldT… int        year  sqlTyp… TRUE     TRUE     NA     NA               NA</span></span>
<span><span class='c'>#&gt; 9 body_mass   esriFieldT… &lt;NA&gt;       body… sqlTyp… TRUE     TRUE     NA     NA               NA</span></span></pre>

You should now see the `body_mass` field listed among the service fields.

## Next Steps

With the new field added to the service definition, you can now populate it with data using [`arcgislayers::update_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html). The field structure is in place and ready to receive values that match the defined field type.

This approach allows you to iteratively expand your feature services as your data requirements evolve, without the need to republish entirely new services.
