# Truncate and append features

From time to time as the owner of a Feature Layer, you may need to completely overwrite the data in the service. Overwriting a web layer from ArcGIS Pro may lead to a loss of associated pop-ups and symbology. One way to get around this is to truncate the feature service and append new data to the same service.

For this example, we need to be the owner of a Feature Service. As such, we will use the North Carolina SIDS dataset we created in the [**Publishing from R**](/layers/publishing) tutorial. If you have not done that tutorial, complete it first.

## Truncating a Feature Layer

Truncating a Feature Layer deletes every single record in the service and resets the auto-increment of the object ID. Truncating a service does not change the field definitions or permit us to add or remove fields. If you wish to do so, publish a new layer instead.

Before we can modify a service, we must first authorize ourselves with the portal. To do so we will use the [`auth_code()`](https://rdrr.io/pkg/arcgisutils/man/auth.html) authorization flow. If you have not yet configured you environment to authorize with your portal, follow the [**Connecting to your Portal**](/authentication/connecting-to-a-portal) tutorial.

First load `arcgis`.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span></pre>

    Attaching core arcgis packages:
      - {arcgisutils} v0.3.0
      - {arcgislayers} v0.2.0

Next, authorize with the portal and set the access token.

<pre class='chroma'>
<span><span class='nv'>token</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/auth.html'>auth_code</a></span><span class='o'>(</span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/token.html'>set_arc_token</a></span><span class='o'>(</span><span class='nv'>token</span><span class='o'>)</span></span></pre>

    Token set to environment variable `ARCGIS_TOKEN`

Now that we have verified our identity with our portal we can create a `FeatureLayer` object in R from our hosted service. From your [content listing](https://arcgis.com/home/content.html) find the Feature Layer url.

<div class="callout-tip">

Revisit the “Obtaining a feature layer url” section of the [**Read hosted data**](/layers/read-layers) tutorial if you forgot how to retrieve the service url.

</div>

<pre class='chroma'>
<span><span class='nv'>furl</span> <span class='o'>&lt;-</span> <span class='s'>"https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/rest/services/North%20Carolina%20SIDS/FeatureServer/0"</span> <span class='c'># &lt;1&gt;</span></span>
<span></span>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/arc_open.html'>arc_open</a></span><span class='o'>(</span><span class='nv'>furl</span><span class='o'>)</span> <span class='c'># &lt;2&gt;</span></span>
<span><span class='nv'>nc</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    CRS: 4267
    Capabilities: Create,Delete,Query,Update,Editing

<div class="aside">

This is the url of your hosted feature service. Yours will be different than the URL shown here. Note that the `/0` indicates the layer index. You can often copy the url from under the URL section on the right hand menu and append the `/0` to it.

</div>

Before we can truncate the `FeatureLayer`, we should check to see that the layer itself supports this operation. The `supportsTruncate` attribute will return `TRUE` if we can truncate it. If not, we’re out of luck and need to create an entirely new service!

<pre class='chroma'>
<span><span class='nv'>nc</span><span class='o'>[[</span><span class='s'>"supportsTruncate"</span><span class='o'>]</span><span class='o'>]</span></span></pre>

Since we know that we can truncate the service, we can go ahead and do so.

<pre class='chroma'>
<span><span class='nv'>truncate_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/truncate_layer.html'>truncate_layer</a></span><span class='o'>(</span><span class='nv'>nc</span><span class='o'>)</span></span>
<span><span class='nv'>truncate_res</span></span></pre>

We store the result into `truncate_res` to see the results. Let’s now go ahead and refresh our layer and check to see if the changes have taken place.

<pre class='chroma'>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/utils.html'>refresh_layer</a></span><span class='o'>(</span><span class='nv'>nc</span><span class='o'>)</span></span>
<span><span class='nv'>nc</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    Capabilities: Create,Delete,Query,Update,Editing

After refreshing the layer we can see that there are now 0 features! Success! There are still 15 fields and we still have the same name and geometry type.

## Adding features

Now that we have deleted all of the features of the layer, lets go ahead and add some new ones. Let’s read the `nc.shp` file from sf into memory, give it a slight modification, and add those features to our service.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://r-spatial.github.io/sf/'>sf</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>nc_sf</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_read.html'>read_sf</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/r/base/system.file.html'>system.file</a></span><span class='o'>(</span><span class='s'>"shape/nc.shp"</span>, package <span class='o'>=</span> <span class='s'>"sf"</span><span class='o'>)</span><span class='o'>)</span></span>
<span><span class='nv'>nc_sf</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 100 features and 14 fields</span></span>
<span><span class='c'>#&gt; Geometry type: MULTIPOLYGON</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -84.32385 ymin: 33.88199 xmax: -75.45698 ymax: 36.58965</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  NAD27</span></span>
<span><span class='c'>#&gt; # A tibble: 100 × 15</span></span>
<span><span class='c'>#&gt;     AREA PERIMETER CNTY_ CNTY_ID NAME      FIPS  FIPSNO CRESS_ID BIR74 SID74 NWBIR74</span></span>
<span><span class='c'>#&gt;    &lt;dbl&gt;     &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt; &lt;chr&gt;     &lt;chr&gt;  &lt;dbl&gt;    &lt;int&gt; &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt;</span></span>
<span><span class='c'>#&gt;  1 0.114      1.44  1825    1825 Ashe      37009  37009        5  1091     1      10</span></span>
<span><span class='c'>#&gt;  2 0.061      1.23  1827    1827 Alleghany 37005  37005        3   487     0      10</span></span>
<span><span class='c'>#&gt;  3 0.143      1.63  1828    1828 Surry     37171  37171       86  3188     5     208</span></span>
<span><span class='c'>#&gt;  4 0.07       2.97  1831    1831 Currituck 37053  37053       27   508     1     123</span></span>
<span><span class='c'>#&gt;  5 0.153      2.21  1832    1832 Northamp… 37131  37131       66  1421     9    1066</span></span>
<span><span class='c'>#&gt;  6 0.097      1.67  1833    1833 Hertford  37091  37091       46  1452     7     954</span></span>
<span><span class='c'>#&gt;  7 0.062      1.55  1834    1834 Camden    37029  37029       15   286     0     115</span></span>
<span><span class='c'>#&gt;  8 0.091      1.28  1835    1835 Gates     37073  37073       37   420     0     254</span></span>
<span><span class='c'>#&gt;  9 0.118      1.42  1836    1836 Warren    37185  37185       93   968     4     748</span></span>
<span><span class='c'>#&gt; 10 0.124      1.43  1837    1837 Stokes    37169  37169       85  1612     1     160</span></span>
<span><span class='c'>#&gt; # ℹ 90 more rows</span></span>
<span><span class='c'>#&gt; # ℹ 4 more variables: BIR79 &lt;dbl&gt;, SID79 &lt;dbl&gt;, NWBIR79 &lt;dbl&gt;,</span></span>
<span><span class='c'>#&gt; #   geometry &lt;MULTIPOLYGON [°]&gt;</span></span></pre>

Rather than publish the polygons as they are, let’s calculate the convex hull of each shape and publish those.

<pre class='chroma'>
<span><span class='nv'>nc_convex</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://r-spatial.github.io/sf/reference/geos_unary.html'>st_convex_hull</a></span><span class='o'>(</span><span class='nv'>nc_sf</span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://rdrr.io/r/graphics/plot.default.html'>plot</a></span><span class='o'>(</span><span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_geometry.html'>st_geometry</a></span><span class='o'>(</span><span class='nv'>nc_convex</span><span class='o'>)</span><span class='o'>)</span></span></pre>

Let’s take this sf object and add them as features to our now empty `FeatureLayer`. To add features, we use the [`add_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html) function. The first argument is the `FeatureLayer` (or `Table`) that we are adding features to. The second is the `sf` object that we will be adding to the layer.

<div class="callout-tip">

It is important to note that the column names of the `sf` object must match the names of the fields in the `FeatureLayer`, otherwise `arcgis` does not know which column matches which field.

</div>

<pre class='chroma'>
<span><span class='nv'>add_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/modify.html'>add_features</a></span><span class='o'>(</span><span class='nv'>nc</span>, <span class='nv'>nc_convex</span><span class='o'>)</span></span></pre>

    Warning: CRS missing from `x` cannot verify matching CRS.

We receive a warning because there is no spatial reference in the hosted `FeatureLayer` after truncating. Print the `add_res` object to see if each feature was successfully added.

<pre class='chroma'>
<span><span class='nf'><a href='https://rdrr.io/r/utils/head.html'>head</a></span><span class='o'>(</span><span class='nv'>add_res</span><span class='o'>)</span></span></pre>

        objectId uniqueId globalId success
    1          1        1       NA    TRUE
    2          2        2       NA    TRUE
    3          3        3       NA    TRUE
    4          4        4       NA    TRUE
    5          5        5       NA    TRUE
    6          6        6       NA    TRUE

Now that we have added our features, let us refresh the layer again.

<pre class='chroma'>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/utils.html'>refresh_layer</a></span><span class='o'>(</span><span class='nv'>nc</span><span class='o'>)</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    CRS: 4267
    Capabilities: Create,Delete,Query,Update,Editing

If you view the hosted Feature Layer in the map viewer, you should now see the convex hulls.

![](../shared/images/nc-sids.png)

<img src="../shared/images/nc-sids.png" width="10" />
