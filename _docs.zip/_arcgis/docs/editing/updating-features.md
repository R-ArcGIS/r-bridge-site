---
title: Updating features
uid: updating-features
---


# Updating features

In the previous section we added a new feature that is the average of our numeric columns and stored the results in the variable `nc_avgs`. When looking at it, we can see that the `AREA` AND `PERIMETER` values are missing. These might be helpful at a later point.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span>
<span><span class='nf'>set_arc_token</span><span class='o'>(</span><span class='nf'>auth_code</span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>nc_url</span> <span class='o'>&lt;-</span> <span class='s'>"https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/rest/services/North%20Carolina%20SIDS/FeatureServer/0"</span> </span>
<span></span>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'>arc_open</span><span class='o'>(</span><span class='nv'>nc_url</span><span class='o'>)</span></span></pre>

In this section we will use the function `update_features()` to modify these values. First, let’s create a new object called `to_update` that has the `AREA` and `PERIMETER` computed.

<pre class='chroma'>
<span><span class='nv'>nc_area_perim</span> <span class='o'>&lt;-</span> <span class='nv'>nc_avgs</span> <span class='o'>|&gt;</span> </span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/mutate.html'>mutate</a></span><span class='o'>(</span></span>
<span>    AREA <span class='o'>=</span> <span class='nf'><a href='https://r-spatial.github.io/sf/reference/geos_measures.html'>st_area</a></span><span class='o'>(</span><span class='nv'>geometry</span><span class='o'>)</span> <span class='o'>/</span> <span class='m'>1e10</span>,</span>
<span>    PERIMETER <span class='o'>=</span> <span class='nf'>s2</span><span class='nf'>::</span><span class='nf'><a href='https://r-spatial.github.io/s2/reference/s2_is_collection.html'>s2_perimeter</a></span><span class='o'>(</span><span class='nv'>geometry</span><span class='o'>)</span> <span class='o'>/</span> <span class='m'>1e5</span></span>
<span>  <span class='o'>)</span></span>
<span></span>
<span><span class='nv'>nc_area_perim</span></span></pre>

    Simple feature collection with 1 feature and 15 fields
    Geometry type: MULTIPOLYGON
    Dimension:     XY
    Bounding box:  xmin: -84.32385 ymin: 33.88199 xmax: -75.45698 ymax: 36.58965
    Geodetic CRS:  NAD27
      object_id           AREA PERIMETER CNTY_ CNTY_ID  NAME FIPS FIPSNO CRESS_ID   BIR74 SID74 NWBIR74   BIR79 SID79 NWBIR79                       geometry
    1       101 12.70259 [m^2]  33.58819    NA      NA Total   NA     NA       NA 3299.62  6.67 1050.81 4223.92  8.36 1352.81 MULTIPOLYGON (((-75.9248 36...

Like `add_features()`, we need to be able to match columns to their respective fields. The `match_on` argument is used to specify if the column names match the field name or field alias.

In the case of `update_features()` we also need to be able to match the features in the `sf` dataset to the *exact* feature in the `FeatureLayer`. We do this by providing the object ID of the feature. This tells ArcGIS *which* features we are actually going to update.

When using `update_features()` we should be aware that *every* column present in the `sf` object will be updated *including the geometry*. For this reason, we should select only those columns which we truly wish to update.

<pre class='chroma'>
<span><span class='nv'>to_update</span> <span class='o'>&lt;-</span> <span class='nv'>nc_area_perim</span> <span class='o'>|&gt;</span> </span>
<span>  <span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_geometry.html'>st_drop_geometry</a></span><span class='o'>(</span><span class='o'>)</span> <span class='o'>|&gt;</span> </span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/select.html'>select</a></span><span class='o'>(</span><span class='nv'>object_id</span>, <span class='nv'>AREA</span>, <span class='nv'>PERIMETER</span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>to_update</span></span></pre>

Here we use [`sf::st_drop_geometry()`](https://r-spatial.github.io/sf/reference/st_geometry.html)to remove the geometry of our object since we do not want to update the geometry in our `FeatureLayer`. We also only select the `object_id`, `AREA`, and `PERIMETER` columns so that we do not make errant updates.

<pre class='chroma'>
<span><span class='nv'>update_res</span> <span class='o'>&lt;-</span> <span class='nf'>update_features</span><span class='o'>(</span><span class='nv'>nc</span>, <span class='nv'>to_update</span><span class='o'>)</span></span></pre>

    $updateResults
      objectId uniqueId globalId success
    1      101      101       NA    TRUE

Our update process was successful! We can repeat our previous query to verify this.

<pre class='chroma'>
<span> <span class='nv'>nc</span> <span class='o'>|&gt;</span> </span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/filter.html'>filter</a></span><span class='o'>(</span><span class='nv'>NAME</span> <span class='o'>==</span> <span class='s'>"Total"</span><span class='o'>)</span> <span class='o'>|&gt;</span> </span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/compute.html'>collect</a></span><span class='o'>(</span><span class='o'>)</span></span></pre>

    Simple feature collection with 1 feature and 15 fields
    Geometry type: MULTIPOLYGON
    Dimension:     XY
    Bounding box:  xmin: -84.32385 ymin: 33.88199 xmax: -75.45698 ymax: 36.58965
    Geodetic CRS:  NAD27
      object_id     AREA PERIMETER CNTY_ CNTY_ID  NAME FIPS FIPSNO CRESS_ID   BIR74 SID74 NWBIR74   BIR79 SID79 NWBIR79                       geometry
    1       101 12.70259  33.58819    NA      NA Total   NA     NA       NA 3299.62  6.67 1050.81 4223.92  8.36 1352.81 MULTIPOLYGON (((-75.9248 36...
