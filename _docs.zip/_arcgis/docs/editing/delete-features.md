# Deleting features

While [`add_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html) and [`update_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html) had a very similar syntax, [`delete_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html) has a somewhat different interface. We have 3 different ways in which we can delete features. Here we will explore only two of them.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/token.html'>set_arc_token</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/auth.html'>auth_code</a></span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>nc_url</span> <span class='o'>&lt;-</span> <span class='s'>"https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/rest/services/North%20Carolina%20SIDS/FeatureServer/0"</span> </span>
<span></span>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/arc_open.html'>arc_open</a></span><span class='o'>(</span><span class='nv'>nc_url</span><span class='o'>)</span></span></pre>

We can delete features based on object IDs or a SQL where clause. Let’s explore deleting features based on object IDs. To do so, we need to pass the `FeatureLayer` obejct as the first argument to [`delete_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html). The second argument is a numeric vector of the IDs we want to delete. The ID `101` is the new feature that we created.

<pre class='chroma'>
<span><span class='nv'>delete_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/modify.html'>delete_features</a></span><span class='o'>(</span><span class='nv'>nc</span>, object_ids <span class='o'>=</span> <span class='m'>101</span><span class='o'>)</span></span>
<span><span class='nv'>delete_res</span></span></pre>

    $deleteResults
      objectId uniqueId globalId success
    1      101      101       NA    TRUE

We can check to see if the delete worked by refreshing the layer and seeing the count that is printed out.

<pre class='chroma'>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/utils.html'>refresh_layer</a></span><span class='o'>(</span><span class='nv'>nc</span><span class='o'>)</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    CRS: 4267
    Capabilities: Create,Delete,Query,Update,Editing

Alternatively, we can delete features based on a `where` clause. Say we wanted to delete all of the features where the `BIR74` value was less than `1000`. We can accomplish this using a where clause.

<pre class='chroma'>
<span><span class='nv'>delete_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/modify.html'>delete_features</a></span><span class='o'>(</span><span class='nv'>nc</span>, where <span class='o'>=</span> <span class='s'>"BIR74 &lt; 1000"</span><span class='o'>)</span></span>
<span><span class='nv'>delete_res</span></span></pre>

    $deleteResults
       objectId uniqueId globalId success
    1         2        2       NA    TRUE
    2         4        4       NA    TRUE
    3         7        7       NA    TRUE
    4         8        8       NA    TRUE
    5         9        9       NA    TRUE
    6        20       20       NA    TRUE
    7        21       21       NA    TRUE
    8        22       22       NA    TRUE
    9        32       32       NA    TRUE
    10       35       35       NA    TRUE
    11       38       38       NA    TRUE
    12       44       44       NA    TRUE
    13       45       45       NA    TRUE
    14       56       56       NA    TRUE
    15       58       58       NA    TRUE
    16       59       59       NA    TRUE
    17       73       73       NA    TRUE
    18       77       77       NA    TRUE
    19       78       78       NA    TRUE
    20       80       80       NA    TRUE
    21       83       83       NA    TRUE
    22       87       87       NA    TRUE
    23       90       90       NA    TRUE

Successful deletes! Again, we can check to see the new count using [`refresh_layer()`](https://rdrr.io/pkg/arcgislayers/man/utils.html).

<pre class='chroma'>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/utils.html'>refresh_layer</a></span><span class='o'>(</span><span class='nv'>nc</span><span class='o'>)</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    CRS: 4267
    Capabilities: Create,Delete,Query,Update,Editing

Lastly, if you want to delete *every single feature*. We can take advantage of the where clause again. If we set `where = "1 = 1"` that will evaluate `TRUE` for every single feature.

<pre class='chroma'>
<span><span class='nv'>delete_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/modify.html'>delete_features</a></span><span class='o'>(</span><span class='nv'>nc</span>, where <span class='o'>=</span> <span class='s'>"1 = 1"</span><span class='o'>)</span></span>
<span><span class='nv'>delete_res</span></span></pre>

    $deleteResults
       objectId uniqueId globalId success
    1         1        1       NA    TRUE
    2         3        3       NA    TRUE
    3         5        5       NA    TRUE
    4         6        6       NA    TRUE
    5        10       10       NA    TRUE
    6        11       11       NA    TRUE
              ... Truncated ...

<pre class='chroma'>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/utils.html'>refresh_layer</a></span><span class='o'>(</span><span class='nv'>nc</span><span class='o'>)</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    CRS: 4267
    Capabilities: Create,Delete,Query,Update,Editing

Note that you shuold use [`truncate_layer()`](https://rdrr.io/pkg/arcgislayers/man/truncate_layer.html) instead of `delete_features(x, where = "1 = 1")`.
