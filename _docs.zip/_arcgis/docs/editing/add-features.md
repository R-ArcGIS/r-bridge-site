# Adding features

Programmatically, adding, deleting, or updating features using [arcgis](https://github.com/R-ArcGIS/arcgis/) is a straightforward process. In this workflow, we illustrate how to add, update, or delete features from an existing hosted feature layer or table.

We will go over the functions:

- [`add_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html)
- [`update_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html)
- [`delete_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html)

## Prerequisites

We will use the the *North Carolina SIDS* dataset we created in the [**Publishing from R**](/layers/publishing) tutorial. To follow along, be sure that you have followed that tutorial and have a `FeatureLayer` that you can modify. If you have not yet configured your environment to authorize with an online portal, start at [**Connecting to your portal**](/authentication/connecting-to-a-portal).

## Adding features

For this example, we will add a single feature to the North Carolina SIDS dataset that is a summary over the entire state. Before we can begin, we must load the package and authorize ourselves as a user.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/R-ArcGIS/arcgis/'>arcgis</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>token</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/auth.html'>auth_code</a></span><span class='o'>(</span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/token.html'>set_arc_token</a></span><span class='o'>(</span><span class='nv'>token</span><span class='o'>)</span></span></pre>

Next, we will create the feature that we want to add using the `sf` package. We’ll read in the `nc.shp` file from the `sf` package.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://r-spatial.github.io/sf/'>sf</a></span><span class='o'>)</span></span>
<span><span class='nv'>nc_sf</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_read.html'>read_sf</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/r/base/system.file.html'>system.file</a></span><span class='o'>(</span><span class='s'>"shape/nc.shp"</span>, package <span class='o'>=</span> <span class='s'>"sf"</span><span class='o'>)</span><span class='o'>)</span></span>
<span><span class='nv'>nc_sf</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 100 features and 14 fields</span></span>
<span><span class='c'>#&gt; Geometry type: MULTIPOLYGON</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -84.32385 ymin: 33.88199 xmax: -75.45698 ymax: 36.58965</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  NAD27</span></span>
<span><span class='c'>#&gt; # A tibble: 100 × 15</span></span>
<span><span class='c'>#&gt;     AREA PERIMETER CNTY_ CNTY_ID NAME      FIPS  FIPSNO CRESS_ID BIR74 SID74 NWBIR74</span></span>
<span><span class='c'>#&gt;    &lt;dbl&gt;     &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt; &lt;chr&gt;     &lt;chr&gt;  &lt;dbl&gt;    &lt;int&gt; &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt;</span></span>
<span><span class='c'>#&gt;  1 0.114      1.44  1825    1825 Ashe      37009  37009        5  1091     1      10</span></span>
<span><span class='c'>#&gt;  2 0.061      1.23  1827    1827 Alleghany 37005  37005        3   487     0      10</span></span>
<span><span class='c'>#&gt;  3 0.143      1.63  1828    1828 Surry     37171  37171       86  3188     5     208</span></span>
<span><span class='c'>#&gt;  4 0.07       2.97  1831    1831 Currituck 37053  37053       27   508     1     123</span></span>
<span><span class='c'>#&gt;  5 0.153      2.21  1832    1832 Northamp… 37131  37131       66  1421     9    1066</span></span>
<span><span class='c'>#&gt;  6 0.097      1.67  1833    1833 Hertford  37091  37091       46  1452     7     954</span></span>
<span><span class='c'>#&gt;  7 0.062      1.55  1834    1834 Camden    37029  37029       15   286     0     115</span></span>
<span><span class='c'>#&gt;  8 0.091      1.28  1835    1835 Gates     37073  37073       37   420     0     254</span></span>
<span><span class='c'>#&gt;  9 0.118      1.42  1836    1836 Warren    37185  37185       93   968     4     748</span></span>
<span><span class='c'>#&gt; 10 0.124      1.43  1837    1837 Stokes    37169  37169       85  1612     1     160</span></span>
<span><span class='c'>#&gt; # ℹ 90 more rows</span></span>
<span><span class='c'>#&gt; # ℹ 4 more variables: BIR79 &lt;dbl&gt;, SID79 &lt;dbl&gt;, NWBIR79 &lt;dbl&gt;,</span></span>
<span><span class='c'>#&gt; #   geometry &lt;MULTIPOLYGON [°]&gt;</span></span></pre>

Let’s calculate the average birth rate, SIDS rate, and the non-white birth rate and SIDS rate for the entire state. We will add this as a single feature to our existing feature layer. To do so, we will use the R package [`dplyr`](https://dplyr.tidyverse.org/) for manipulating our data.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://dplyr.tidyverse.org'>dplyr</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>nc_summary</span> <span class='o'>&lt;-</span> <span class='nv'>nc_sf</span> <span class='o'>|&gt;</span>  </span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/summarise.html'>summarise</a></span><span class='o'>(</span></span>
<span>    <span class='nf'><a href='https://dplyr.tidyverse.org/reference/across.html'>across</a></span><span class='o'>(</span> <span class='c'># &lt;1&gt;</span></span>
<span>      .cols <span class='o'>=</span> <span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='nf'><a href='https://tidyselect.r-lib.org/reference/starts_with.html'>ends_with</a></span><span class='o'>(</span><span class='s'>"74"</span><span class='o'>)</span>, <span class='nf'><a href='https://tidyselect.r-lib.org/reference/starts_with.html'>ends_with</a></span><span class='o'>(</span><span class='s'>"79"</span><span class='o'>)</span><span class='o'>)</span>, <span class='c'># &lt;2&gt;</span></span>
<span>      .fns <span class='o'>=</span> <span class='nv'>mean</span> <span class='c'># &lt;3&gt;</span></span>
<span>    <span class='o'>)</span>,</span>
<span>    NAME <span class='o'>=</span> <span class='s'>"Total"</span> <span class='c'># &lt;4&gt;</span></span>
<span>  <span class='o'>)</span> </span>
<span></span>
<span><span class='nv'>nc_summary</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 1 feature and 7 fields</span></span>
<span><span class='c'>#&gt; Geometry type: MULTIPOLYGON</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -84.32385 ymin: 33.88199 xmax: -75.45698 ymax: 36.58965</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  NAD27</span></span>
<span><span class='c'>#&gt; # A tibble: 1 × 8</span></span>
<span><span class='c'>#&gt;   BIR74 SID74 NWBIR74 BIR79 SID79 NWBIR79 NAME                              geometry</span></span>
<span><span class='c'>#&gt;   &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt; &lt;dbl&gt; &lt;dbl&gt;   &lt;dbl&gt; &lt;chr&gt;                   &lt;MULTIPOLYGON [°]&gt;</span></span>
<span><span class='c'>#&gt; 1 3300.  6.67   1051. 4224.  8.36   1353. Total (((-75.97629 36.51793, -75.97728 36…</span></span></pre>

1.  The [`across()`](https://dplyr.tidyverse.org/reference/across.html) function applies a function to multiple columns at once.
2.  We specify the columns we will be applying a function to in `.cols`. We use the `tidyselect` helpers to catch any columns that end with `74` or `79`.
3.  The `.fns` argument specifies which functions will be applied to the columns. In this case, we apply on the [`mean()`](https://rdrr.io/r/base/mean.html) function to calculate the average.
4.  The `NAME` field is set manually to the value of `"Total"` to indicate that it is not a county.

In order to add this new aggregate feature to the `FeatureLayer` we must create a reference to the layer using [`arc_open()`](https://rdrr.io/pkg/arcgislayers/man/arc_open.html).

<pre class='chroma'>
<span><span class='nv'>nc_url</span> <span class='o'>&lt;-</span> <span class='s'>"https://services1.arcgis.com/hLJbHVT9ZrDIzK0I/arcgis/rest/services/North%20Carolina%20SIDS/FeatureServer/0"</span> </span>
<span></span>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/arc_open.html'>arc_open</a></span><span class='o'>(</span><span class='nv'>nc_url</span><span class='o'>)</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    CRS: 4267
    Capabilities: Create,Delete,Query,Update,Editing

<div class="callout-note">

The url you use here will be different than the one you see. Be sure to grab the correct url from the content listing for your item.

</div>

Now that we have a `FeatureLayer` object we can add features to it using [`add_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html). There are a few key arguments to the function:

- `x` is the `FeatureLayer` object that we want to add features to
- `.data` is an `sf` object that we want to add to the `FeatureLayer`
- `match_on` determines how to match sf columns to `FeatureLayer` fields

By default, [`add_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html) will compare the column names of the `sf` object to that of the `FeatureLayer`. We can find the field names and aliases for a `FeatureLayer` by using the [`list_fields()`](https://rdrr.io/pkg/arcgislayers/man/utils.html) function. Pass the results to [`tibble::as_tibble()`](https://tibble.tidyverse.org/reference/as_tibble.html) to make them more readable.

Since we know that the column names match those of the `FeatureLayer`, we can pass `nc_summary` directly to `add_feature()`.

<pre class='chroma'>
<span><span class='nv'>add_res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/modify.html'>add_features</a></span><span class='o'>(</span><span class='nv'>nc</span>, <span class='nv'>nc_summary</span><span class='o'>)</span></span>
<span><span class='nv'>add_res</span></span></pre>

      objectId uniqueId globalId success
    1      101      101       NA    TRUE

<div class="callout-tip">

If you are adding many features at one time, consider changing the value of `chunk_size`. By default, [`add_features()`](https://rdrr.io/pkg/arcgislayers/man/modify.html) will add up to 2000 features at a time and send the requests in parallel. Depending on the geometry type and precision, it may be worthwhile to make that number smaller. If the data are truly massive, consider breaking up the task into smaller manageable chunks.

</div>

Once we’ve added the results to the `FeatureLayer`, we may want to refresh the object to catch any important changes to the metadata.

<pre class='chroma'>
<span><span class='nv'>nc</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/utils.html'>refresh_layer</a></span><span class='o'>(</span><span class='nv'>nc</span><span class='o'>)</span></span></pre>

    <FeatureLayer>
    Name: North Carolina SIDS
    Geometry Type: esriGeometryPolygon
    CRS: 4267
    Capabilities: Create,Delete,Query,Update,Editing

We can see that the `FeatureLayer` now has 101 features as opposed to the original 100. To sanity check, we can query `nc` to see how the value comes back.

<pre class='chroma'>
<span><span class='nv'>nc_avgs</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/arc_select.html'>arc_select</a></span><span class='o'>(</span><span class='nv'>nc</span>, where <span class='o'>=</span> <span class='s'>'NAME = "Total"'</span><span class='o'>)</span></span>
<span><span class='nv'>nc_avgs</span></span></pre>

    Simple feature collection with 1 feature and 15 fields
    Geometry type: MULTIPOLYGON
    Dimension:     XY
    Bounding box:  xmin: -84.32385 ymin: 33.88199 xmax: -75.45698 ymax: 36.58965
    Geodetic CRS:  NAD27
      object_id AREA PERIMETER CNTY_ CNTY_ID  NAME FIPS FIPSNO CRESS_ID   BIR74 SID74 NWBIR74   BIR79 SID79 NWBIR79                       geometry
    1       101   NA        NA    NA      NA Total   NA     NA       NA 3299.62  6.67 1050.81 4223.92  8.36 1352.81 MULTIPOLYGON (((-75.9248 36...
