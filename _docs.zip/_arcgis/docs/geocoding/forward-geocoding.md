---
title: Forward geocoding
uid: forward-geocoding
---


# Forward geocoding

Forward geocoding is the process of taking an address or place information and identifying its location on the globe.

To geocode addresses, the [arcgisgeocode](https://github.com/r-arcgis/arcgisgeocode) package provides the function [`find_address_candidates()`](https://rdrr.io/pkg/arcgisgeocode/man/find_address_candidates.html). This function geocodes a single address at a time and returns up to 50 address candidates (ranked by a score).

There are two ways in which you can provide address information:

1.  Provide the entire address as a string via the `single_line` argument
2.  Provide parts of the address using the arguments `address`, `city`, `region`, `postal` etc.

## Single line address geocoding

It can be tough to parse out addresses into their components. Using the `single_line` argument is a very flexible way of geocoding addresses. Doing utilizes the ArcGIS World Geocoder’s address parsing capabilities.

For example, we can geocode the same location using 3 decreasingly specific addresses.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/r-arcgis/arcgisgeocode'>arcgisgeocode</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>addresses</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span></span>
<span>  <span class='s'>"380 New York Street Redlands, California, 92373, USA"</span>,</span>
<span>  <span class='s'>"Esri Redlands"</span>,</span>
<span>  <span class='s'>"ESRI CA"</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>locs</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/find_address_candidates.html'>find_address_candidates</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>addresses</span>,</span>
<span>  max_locations <span class='o'>=</span> <span class='m'>1L</span></span>
<span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>locs</span><span class='o'>$</span><span class='nv'>geometry</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Geometry set for 3 features </span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -117.1948 ymin: 34.05724 xmax: -117.1948 ymax: 34.05724</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span></span>
<span><span class='c'>#&gt; POINT (-117.1948 34.05724)</span></span>
<span></span>
<span><span class='c'>#&gt; POINT (-117.1957 34.05609)</span></span>
<span><span class='c'>#&gt; POINT (-117.1957 34.05609)</span></span></pre>

In each case, it finds the correct address!

## Geocoding from a dataframe

Most commonly, you will need to geocode addresses from a column in a data.frame. It is important to note that the [`find_address_candidates()`](https://rdrr.io/pkg/arcgisgeocode/man/find_address_candidates.html) function does not work well in a [`dplyr::mutate()`](https://dplyr.tidyverse.org/reference/mutate.html) function call. Particularly because it is possible to return more than 1 address at a time.

Let’s read in a csv of bike stores in Tacoma, WA. To use [`find_address_candidates()`](https://rdrr.io/pkg/arcgisgeocode/man/find_address_candidates.html) with a data.frame, it is recommended to create a unique identifier of the row positions.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://dplyr.tidyverse.org'>dplyr</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>fp</span> <span class='o'>&lt;-</span> <span class='s'>"https://www.arcgis.com/sharing/rest/content/items/9a9b91179ac44db1b689b42017471ae6/data"</span></span>
<span></span>
<span><span class='nv'>bike_stores</span> <span class='o'>&lt;-</span> <span class='nf'>readr</span><span class='nf'>::</span><span class='nf'><a href='https://readr.tidyverse.org/reference/read_delim.html'>read_csv</a></span><span class='o'>(</span><span class='nv'>fp</span><span class='o'>)</span> <span class='o'>|&gt;</span></span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/mutate.html'>mutate</a></span><span class='o'>(</span>id <span class='o'>=</span> <span class='nf'><a href='https://dplyr.tidyverse.org/reference/row_number.html'>row_number</a></span><span class='o'>(</span><span class='o'>)</span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>bike_stores</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; # A tibble: 10 × 3</span></span>
<span><span class='c'>#&gt;    store_name                           original_address                      id</span></span>
<span><span class='c'>#&gt;    &lt;chr&gt;                                &lt;chr&gt;                              &lt;int&gt;</span></span>
<span><span class='c'>#&gt;  1 Cascadia Wheel Co.                   3320 N Proctor St, Tacoma, WA 984…     1</span></span>
<span><span class='c'>#&gt;  2 Puget Sound Bike and Ski Shop        between 3206 N. 15th and 1414, N …     2</span></span>
<span><span class='c'>#&gt;  3 Takoma Bike &amp; Ski                    3010 6th Ave, Tacoma, WA 98406         3</span></span>
<span><span class='c'>#&gt;  4 Trek Bicycle Tacoma University Place 3550 Market Pl W Suite 102, Unive…     4</span></span>
<span><span class='c'>#&gt;  5 Opalescent Cyclery                   814 6th Ave, Tacoma, WA 98405          5</span></span>
<span><span class='c'>#&gt;  6 Sound Bikes                          108 W Main, Puyallup, WA 98371         6</span></span>
<span><span class='c'>#&gt;  7 Trek Bicycle Tacoma North End        3009 McCarver St, Tacoma, WA 98403     7</span></span>
<span><span class='c'>#&gt;  8 Second Cycle                         1205 M.L.K. Jr Way, Tacoma, WA 98…     8</span></span>
<span><span class='c'>#&gt;  9 Penny bike co.                       6419 24th St NE, Tacoma, WA 98422      9</span></span>
<span><span class='c'>#&gt; 10 Spider's Bike, Ski &amp; Tennis Lab      3608 Grandview St, Gig Harbor, WA…    10</span></span></pre>

To geocode addresses from a data.frame, you can use [`dplyr::reframe()`](https://dplyr.tidyverse.org/reference/reframe.html).

<pre class='chroma'>
<span><span class='nv'>bike_stores</span> <span class='o'>|&gt;</span></span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/reframe.html'>reframe</a></span><span class='o'>(</span></span>
<span>    <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/find_address_candidates.html'>find_address_candidates</a></span><span class='o'>(</span><span class='nv'>original_address</span><span class='o'>)</span></span>
<span>  <span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; # A tibble: 15 × 65</span></span>
<span><span class='c'>#&gt;    input_id result_id loc_name status score match_addr    long_label short_label</span></span>
<span><span class='c'>#&gt;       &lt;int&gt;     &lt;int&gt; &lt;chr&gt;    &lt;chr&gt;  &lt;dbl&gt; &lt;chr&gt;         &lt;chr&gt;      &lt;chr&gt;      </span></span>
<span><span class='c'>#&gt;  1        1        NA World    M      100   3320 N Proct… 3320 N Pr… 3320 N Pro…</span></span>
<span><span class='c'>#&gt;  2        2        NA World    M       97.3 1414 N Alder… 1414 N Al… 1414 N Ald…</span></span>
<span><span class='c'>#&gt;  3        2        NA World    M       92.2 N 15th St &amp; … N 15th St… N 15th St …</span></span>
<span><span class='c'>#&gt;  4        2        NA World    M       89.5 S 15th St &amp; … S 15th St… S 15th St …</span></span>
<span><span class='c'>#&gt;  5        2        NA World    M       87.3 N Alder St, … N Alder S… N Alder St </span></span>
<span><span class='c'>#&gt;  6        2        NA World    M       84.4 3206 N 15th … 3206 N 15… 3206 N 15t…</span></span>
<span><span class='c'>#&gt;  7        3        NA World    M      100   3010 6th Ave… 3010 6th … 3010 6th A…</span></span>
<span><span class='c'>#&gt;  8        4        NA World    M      100   3550 Market … 3550 Mark… 3550 Marke…</span></span>
<span><span class='c'>#&gt;  9        5        NA World    M      100   814 6th Ave,… 814 6th A… 814 6th Ave</span></span>
<span><span class='c'>#&gt; 10        6        NA World    M      100   108 W Main, … 108 W Mai… 108 W Main </span></span>
<span><span class='c'>#&gt; 11        7        NA World    M      100   3009 McCarve… 3009 McCa… 3009 McCar…</span></span>
<span><span class='c'>#&gt; 12        8        NA World    M      100   1205 Martin … 1205 Mart… 1205 Marti…</span></span>
<span><span class='c'>#&gt; 13        9        NA World    M       97.9 6419 24th St… 6419 24th… 6419 24th …</span></span>
<span><span class='c'>#&gt; 14       10        NA World    M      100   3608 Grandvi… 3608 Gran… 3608 Grand…</span></span>
<span><span class='c'>#&gt; 15       10        NA World    M       95.5 Grandview St… Grandview… Grandview …</span></span>
<span><span class='c'>#&gt; # ℹ 57 more variables: addr_type &lt;chr&gt;, type_field &lt;chr&gt;, place_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   place_addr &lt;chr&gt;, phone &lt;chr&gt;, url &lt;chr&gt;, rank &lt;dbl&gt;, add_bldg &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   add_num &lt;chr&gt;, add_num_from &lt;chr&gt;, add_num_to &lt;chr&gt;, add_range &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   side &lt;chr&gt;, st_pre_dir &lt;chr&gt;, st_pre_type &lt;chr&gt;, st_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   st_type &lt;chr&gt;, st_dir &lt;chr&gt;, bldg_type &lt;chr&gt;, bldg_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   level_type &lt;chr&gt;, level_name &lt;chr&gt;, unit_type &lt;chr&gt;, unit_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   sub_addr &lt;chr&gt;, st_addr &lt;chr&gt;, block &lt;chr&gt;, sector &lt;chr&gt;, nbrhd &lt;chr&gt;, …</span></span></pre>

Notice how there are multiple results for each `input_id`. This is because the `max_locations` argument was not specified. To ensure only the best match is returned set `max_locations = 1`

<pre class='chroma'>
<span><span class='nv'>geocoded</span> <span class='o'>&lt;-</span> <span class='nv'>bike_stores</span> <span class='o'>|&gt;</span></span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/reframe.html'>reframe</a></span><span class='o'>(</span></span>
<span>    <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/find_address_candidates.html'>find_address_candidates</a></span><span class='o'>(</span><span class='nv'>original_address</span>, max_locations <span class='o'>=</span> <span class='m'>1</span><span class='o'>)</span></span>
<span>  <span class='o'>)</span> <span class='o'>|&gt;</span></span>
<span>  <span class='c'># reframe drops the sf class, must be added</span></span>
<span>  <span class='nf'>sf</span><span class='nf'>::</span><span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_as_sf.html'>st_as_sf</a></span><span class='o'>(</span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>geocoded</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 10 features and 64 fields</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -122.5871 ymin: 47.19168 xmax: -122.294 ymax: 47.32302</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A tibble: 10 × 65</span></span>
<span><span class='c'>#&gt;    input_id result_id loc_name status score match_addr    long_label short_label</span></span>
<span><span class='c'>#&gt;       &lt;int&gt;     &lt;int&gt; &lt;chr&gt;    &lt;chr&gt;  &lt;dbl&gt; &lt;chr&gt;         &lt;chr&gt;      &lt;chr&gt;      </span></span>
<span><span class='c'>#&gt;  1        1        NA World    M      100   3320 N Proct… 3320 N Pr… 3320 N Pro…</span></span>
<span><span class='c'>#&gt;  2        2        NA World    M       97.3 1414 N Alder… 1414 N Al… 1414 N Ald…</span></span>
<span><span class='c'>#&gt;  3        3        NA World    M      100   3010 6th Ave… 3010 6th … 3010 6th A…</span></span>
<span><span class='c'>#&gt;  4        4        NA World    M      100   3550 Market … 3550 Mark… 3550 Marke…</span></span>
<span><span class='c'>#&gt;  5        5        NA World    M      100   814 6th Ave,… 814 6th A… 814 6th Ave</span></span>
<span><span class='c'>#&gt;  6        6        NA World    M      100   108 W Main, … 108 W Mai… 108 W Main </span></span>
<span><span class='c'>#&gt;  7        7        NA World    M      100   3009 McCarve… 3009 McCa… 3009 McCar…</span></span>
<span><span class='c'>#&gt;  8        8        NA World    M      100   1205 Martin … 1205 Mart… 1205 Marti…</span></span>
<span><span class='c'>#&gt;  9        9        NA World    M       97.9 6419 24th St… 6419 24th… 6419 24th …</span></span>
<span><span class='c'>#&gt; 10       10        NA World    M      100   3608 Grandvi… 3608 Gran… 3608 Grand…</span></span>
<span><span class='c'>#&gt; # ℹ 57 more variables: addr_type &lt;chr&gt;, type_field &lt;chr&gt;, place_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   place_addr &lt;chr&gt;, phone &lt;chr&gt;, url &lt;chr&gt;, rank &lt;dbl&gt;, add_bldg &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   add_num &lt;chr&gt;, add_num_from &lt;chr&gt;, add_num_to &lt;chr&gt;, add_range &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   side &lt;chr&gt;, st_pre_dir &lt;chr&gt;, st_pre_type &lt;chr&gt;, st_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   st_type &lt;chr&gt;, st_dir &lt;chr&gt;, bldg_type &lt;chr&gt;, bldg_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   level_type &lt;chr&gt;, level_name &lt;chr&gt;, unit_type &lt;chr&gt;, unit_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   sub_addr &lt;chr&gt;, st_addr &lt;chr&gt;, block &lt;chr&gt;, sector &lt;chr&gt;, nbrhd &lt;chr&gt;, …</span></span></pre>

With this result, you can now join the address fields back onto the `bike_stores` data.frame using a [`left_join()`](https://dplyr.tidyverse.org/reference/mutate-joins.html).

<pre class='chroma'>
<span><span class='nf'><a href='https://dplyr.tidyverse.org/reference/mutate-joins.html'>left_join</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>bike_stores</span>,</span>
<span>  <span class='nv'>geocoded</span>,</span>
<span>  by <span class='o'>=</span> <span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='s'>"id"</span> <span class='o'>=</span> <span class='s'>"input_id"</span><span class='o'>)</span></span>
<span><span class='o'>)</span> <span class='o'>|&gt;</span></span>
<span>  <span class='c'># left_join keeps the class of the first table</span></span>
<span>  <span class='c'># must add sf class back on</span></span>
<span>  <span class='nf'>sf</span><span class='nf'>::</span><span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_as_sf.html'>st_as_sf</a></span><span class='o'>(</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 10 features and 66 fields</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -122.5871 ymin: 47.19168 xmax: -122.294 ymax: 47.32302</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A tibble: 10 × 67</span></span>
<span><span class='c'>#&gt;    store_name  original_address    id result_id loc_name status score match_addr</span></span>
<span><span class='c'>#&gt;    &lt;chr&gt;       &lt;chr&gt;            &lt;int&gt;     &lt;int&gt; &lt;chr&gt;    &lt;chr&gt;  &lt;dbl&gt; &lt;chr&gt;     </span></span>
<span><span class='c'>#&gt;  1 Cascadia W… 3320 N Proctor …     1        NA World    M      100   3320 N Pr…</span></span>
<span><span class='c'>#&gt;  2 Puget Soun… between 3206 N.…     2        NA World    M       97.3 1414 N Al…</span></span>
<span><span class='c'>#&gt;  3 Takoma Bik… 3010 6th Ave, T…     3        NA World    M      100   3010 6th …</span></span>
<span><span class='c'>#&gt;  4 Trek Bicyc… 3550 Market Pl …     4        NA World    M      100   3550 Mark…</span></span>
<span><span class='c'>#&gt;  5 Opalescent… 814 6th Ave, Ta…     5        NA World    M      100   814 6th A…</span></span>
<span><span class='c'>#&gt;  6 Sound Bikes 108 W Main, Puy…     6        NA World    M      100   108 W Mai…</span></span>
<span><span class='c'>#&gt;  7 Trek Bicyc… 3009 McCarver S…     7        NA World    M      100   3009 McCa…</span></span>
<span><span class='c'>#&gt;  8 Second Cyc… 1205 M.L.K. Jr …     8        NA World    M      100   1205 Mart…</span></span>
<span><span class='c'>#&gt;  9 Penny bike… 6419 24th St NE…     9        NA World    M       97.9 6419 24th…</span></span>
<span><span class='c'>#&gt; 10 Spider's B… 3608 Grandview …    10        NA World    M      100   3608 Gran…</span></span>
<span><span class='c'>#&gt; # ℹ 59 more variables: long_label &lt;chr&gt;, short_label &lt;chr&gt;, addr_type &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   type_field &lt;chr&gt;, place_name &lt;chr&gt;, place_addr &lt;chr&gt;, phone &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   url &lt;chr&gt;, rank &lt;dbl&gt;, add_bldg &lt;chr&gt;, add_num &lt;chr&gt;, add_num_from &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   add_num_to &lt;chr&gt;, add_range &lt;chr&gt;, side &lt;chr&gt;, st_pre_dir &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   st_pre_type &lt;chr&gt;, st_name &lt;chr&gt;, st_type &lt;chr&gt;, st_dir &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   bldg_type &lt;chr&gt;, bldg_name &lt;chr&gt;, level_type &lt;chr&gt;, level_name &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   unit_type &lt;chr&gt;, unit_name &lt;chr&gt;, sub_addr &lt;chr&gt;, st_addr &lt;chr&gt;, …</span></span></pre>
