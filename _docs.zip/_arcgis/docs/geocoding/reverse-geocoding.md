---
title: Reverse geocoding
uid: reverse-geocoding
---


# Reverse geocoding

Often you may coordinates of locations but need their addresses as well. **Reverse geocoding** finds an address associated with a location on earth.

Use [`arcgisgeocode::reverse_geocode()`](https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html) to perform reverse geocoding. Using this fuction you can

- reverse geocode an `sfc_POINT` geometry column from the [sf](https://r-spatial.github.io/sf/) package
- reverse geocode a matrix of coordinates
- reverse geocode a single location as a length 2 vector e.g. `c(-117, 34)`

## Reverse geocode a single point

First, load the R package.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://github.com/r-arcgis/arcgisgeocode'>arcgisgeocode</a></span><span class='o'>)</span></span></pre>

You can reverse geocode a single longitude/latitude pair as a length 2 vector with [`reverse_geocode()`](https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html).

<pre class='chroma'>
<span><span class='c'># Find addresses from locations</span></span>
<span><span class='nv'>res</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html'>reverse_geocode</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='o'>-</span><span class='m'>117.172</span>, <span class='m'>34.052</span><span class='o'>)</span><span class='o'>)</span></span>
<span><span class='nf'>dplyr</span><span class='nf'>::</span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>res</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 1</span></span>
<span><span class='c'>#&gt; Columns: 23</span></span>
<span><span class='c'>#&gt; $ match_addr   &lt;chr&gt; "600-620 Home Pl, Redlands, California, 92374"</span></span>
<span><span class='c'>#&gt; $ long_label   &lt;chr&gt; "600-620 Home Pl, Redlands, CA, 92374, USA"</span></span>
<span><span class='c'>#&gt; $ short_label  &lt;chr&gt; "600-620 Home Pl"</span></span>
<span><span class='c'>#&gt; $ addr_type    &lt;chr&gt; "StreetAddress"</span></span>
<span><span class='c'>#&gt; $ type_field   &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ place_name   &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ add_num      &lt;chr&gt; "604"</span></span>
<span><span class='c'>#&gt; $ address      &lt;chr&gt; "604 Home Pl"</span></span>
<span><span class='c'>#&gt; $ block        &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ sector       &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ neighborhood &lt;chr&gt; "South Redlands"</span></span>
<span><span class='c'>#&gt; $ district     &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ city         &lt;chr&gt; "Redlands"</span></span>
<span><span class='c'>#&gt; $ metro_area   &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ subregion    &lt;chr&gt; "San Bernardino County"</span></span>
<span><span class='c'>#&gt; $ region       &lt;chr&gt; "California"</span></span>
<span><span class='c'>#&gt; $ region_abbr  &lt;chr&gt; "CA"</span></span>
<span><span class='c'>#&gt; $ territory    &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ postal       &lt;chr&gt; "92374"</span></span>
<span><span class='c'>#&gt; $ postal_ext   &lt;chr&gt; ""</span></span>
<span><span class='c'>#&gt; $ country_name &lt;chr&gt; "United States"</span></span>
<span><span class='c'>#&gt; $ country_code &lt;chr&gt; "USA"</span></span>
<span><span class='c'>#&gt; $ geometry     &lt;POINT [°]&gt; POINT (-117.172 34.05204)</span></span></pre>
<div class="callout-important">

It is important to note that when you are not using an `sfc_POINT` object, the coordinate reference system is not known. So it is assumed to be `EPSG:4326`. If you provide values outside of \[-180, 180\] and \[-90, 90\] for longitude or latitude, an error will occur.

</div>

## Reverse geocode from an sf object

More commonly, you may have an sf object that you want to reverse geocode their locations. To demonstrate this, you will reverse geocode a csv of state capitals.

First, read the csv file into a data.frame and convert it to an sf object.

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://r-spatial.github.io/sf/'>sf</a></span><span class='o'>)</span></span>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://dplyr.tidyverse.org'>dplyr</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='c'># USA State Capitals</span></span>
<span><span class='nv'>fp</span> <span class='o'>&lt;-</span> <span class='s'>"https://analysis-1.maps.arcgis.com/sharing/rest/content/items/85bcfca158d641b99e7579b47cfee91e/data"</span></span>
<span></span>
<span><span class='c'># read the csv</span></span>
<span><span class='nv'>capitals</span> <span class='o'>&lt;-</span> <span class='nf'>readr</span><span class='nf'>::</span><span class='nf'><a href='https://readr.tidyverse.org/reference/read_delim.html'>read_csv</a></span><span class='o'>(</span><span class='nv'>fp</span><span class='o'>)</span> <span class='o'>|&gt;</span></span>
<span>  <span class='c'># convert to an sf object with EPSG:4326</span></span>
<span>  <span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_as_sf.html'>st_as_sf</a></span><span class='o'>(</span></span>
<span>    coords <span class='o'>=</span> <span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='s'>"longitude"</span>, <span class='s'>"latitude"</span><span class='o'>)</span>,</span>
<span>    crs <span class='o'>=</span> <span class='m'>4326</span></span>
<span>  <span class='o'>)</span></span>
<span></span>
<span><span class='nv'>capitals</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 50 features and 2 fields</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -157.8574 ymin: 21.30744 xmax: -69.78169 ymax: 58.3016</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A tibble: 50 × 3</span></span>
<span><span class='c'>#&gt;    name        description              geometry</span></span>
<span><span class='c'>#&gt;  * &lt;chr&gt;       &lt;chr&gt;                 &lt;POINT [°]&gt;</span></span>
<span><span class='c'>#&gt;  1 Alabama     Montgomery   (-86.30057 32.37772)</span></span>
<span><span class='c'>#&gt;  2 Alaska      Juneau        (-134.4202 58.3016)</span></span>
<span><span class='c'>#&gt;  3 Arizona     Phoenix       (-112.097 33.44814)</span></span>
<span><span class='c'>#&gt;  4 Arkansas    Little Rock  (-92.28899 34.74661)</span></span>
<span><span class='c'>#&gt;  5 California  Sacramento   (-121.4936 38.57667)</span></span>
<span><span class='c'>#&gt;  6 Colorado    Denver       (-104.9849 39.73923)</span></span>
<span><span class='c'>#&gt;  7 Connecticut Hartford&lt;br&gt;  (-72.6822 41.76405)</span></span>
<span><span class='c'>#&gt;  8 Delaware    Dover        (-75.51972 39.15731)</span></span>
<span><span class='c'>#&gt;  9 Hawaii      Honolulu     (-157.8574 21.30744)</span></span>
<span><span class='c'>#&gt; 10 Florida     Tallahassee   (-84.2813 30.43812)</span></span>
<span><span class='c'>#&gt; # ℹ 40 more rows</span></span></pre>

Use [`reverse_geocode()`](https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html) with the geometry column from the capitals to create a new sf object with the address information.

<pre class='chroma'>
<span><span class='nv'>geocoded</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html'>reverse_geocode</a></span><span class='o'>(</span><span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_geometry.html'>st_geometry</a></span><span class='o'>(</span><span class='nv'>capitals</span><span class='o'>)</span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>geocoded</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 50</span></span>
<span><span class='c'>#&gt; Columns: 23</span></span>
<span><span class='c'>#&gt; $ match_addr   &lt;chr&gt; "Psiquicos del Amor y Sanacion", "Gold Creek Cafe", "Arizona Capitol Mus…</span></span>
<span><span class='c'>#&gt; $ long_label   &lt;chr&gt; "Psiquicos del Amor y Sanacion, 600 Dexter Ave, Montgomery, AL, 36130, U…</span></span>
<span><span class='c'>#&gt; $ short_label  &lt;chr&gt; "Psiquicos del Amor y Sanacion", "Gold Creek Cafe", "Arizona Capitol Mus…</span></span>
<span><span class='c'>#&gt; $ addr_type    &lt;chr&gt; "POI", "POI", "POI", "POI", "POI", "POI", "POI", "POI", "POI", "POI", "P…</span></span>
<span><span class='c'>#&gt; $ type_field   &lt;chr&gt; "Other Professional Place", "Restaurant", "Specialty Store", "Government…</span></span>
<span><span class='c'>#&gt; $ place_name   &lt;chr&gt; "Psiquicos del Amor y Sanacion", "Gold Creek Cafe", "Arizona Capitol Mus…</span></span>
<span><span class='c'>#&gt; $ add_num      &lt;chr&gt; "600", "709", "1700", "500", "1315", "101", "210", "411", "415", "", "21…</span></span>
<span><span class='c'>#&gt; $ address      &lt;chr&gt; "600 Dexter Ave", "709 W 9th St", "1700 W Washington St", "500 Capitol M…</span></span>
<span><span class='c'>#&gt; $ block        &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ sector       &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ neighborhood &lt;chr&gt; "", "", "", "", "Downtown Sacramento", "", "Downtown Hartford", "", "Dow…</span></span>
<span><span class='c'>#&gt; $ district     &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ city         &lt;chr&gt; "Montgomery", "Juneau", "Phoenix", "Little Rock", "Sacramento", "Denver"…</span></span>
<span><span class='c'>#&gt; $ metro_area   &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ subregion    &lt;chr&gt; "Montgomery County", "Juneau City and Borough", "Maricopa County", "Pula…</span></span>
<span><span class='c'>#&gt; $ region       &lt;chr&gt; "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "C…</span></span>
<span><span class='c'>#&gt; $ region_abbr  &lt;chr&gt; "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "HI", "FL", "GA", "ID", …</span></span>
<span><span class='c'>#&gt; $ territory    &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ postal       &lt;chr&gt; "36130", "99801", "85007", "72201", "95814", "80203", "06106", "19901", …</span></span>
<span><span class='c'>#&gt; $ postal_ext   &lt;chr&gt; "", "", "", "", "", "", "1501", "", "", "", "", "0001", "", "", "", "150…</span></span>
<span><span class='c'>#&gt; $ country_name &lt;chr&gt; "United States", "United States", "United States", "United States", "Uni…</span></span>
<span><span class='c'>#&gt; $ country_code &lt;chr&gt; "USA", "USA", "USA", "USA", "USA", "USA", "USA", "USA", "USA", "USA", "U…</span></span>
<span><span class='c'>#&gt; $ geometry     &lt;POINT [°]&gt; POINT (-86.30052 32.37772), POINT (-134.4203 58.30155), POINT (-11…</span></span></pre>

Then, you can use dplyr (or base R via [`cbind()`](https://rdrr.io/r/base/cbind.html)) to combine the two datasets. In this example, the geometry column from the reverse geocoding results is drops. This prevents dplyr from renaming the duplicate columns and preserves the sf class.

<pre class='chroma'>
<span><span class='nf'><a href='https://dplyr.tidyverse.org/reference/bind_cols.html'>bind_cols</a></span><span class='o'>(</span></span>
<span>  <span class='nv'>capitals</span>,</span>
<span>  <span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_geometry.html'>st_drop_geometry</a></span><span class='o'>(</span><span class='nv'>geocoded</span><span class='o'>)</span></span>
<span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 50 features and 24 fields</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -157.8574 ymin: 21.30744 xmax: -69.78169 ymax: 58.3016</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A tibble: 50 × 25</span></span>
<span><span class='c'>#&gt;    name       description             geometry match_addr      long_label short_label addr_type</span></span>
<span><span class='c'>#&gt;  * &lt;chr&gt;      &lt;chr&gt;                &lt;POINT [°]&gt; &lt;chr&gt;           &lt;chr&gt;      &lt;chr&gt;       &lt;chr&gt;    </span></span>
<span><span class='c'>#&gt;  1 Alabama    Montgomery  (-86.30057 32.37772) Psiquicos del … Psiquicos… Psiquicos … POI      </span></span>
<span><span class='c'>#&gt;  2 Alaska     Juneau       (-134.4202 58.3016) Gold Creek Cafe Gold Cree… Gold Creek… POI      </span></span>
<span><span class='c'>#&gt;  3 Arizona    Phoenix      (-112.097 33.44814) Arizona Capito… Arizona C… Arizona Ca… POI      </span></span>
<span><span class='c'>#&gt;  4 Arkansas   Little Rock (-92.28899 34.74661) Arkansas State… Arkansas … Arkansas S… POI      </span></span>
<span><span class='c'>#&gt;  5 California Sacramento  (-121.4936 38.57667) California Sta… Californi… California… POI      </span></span>
<span><span class='c'>#&gt;  6 Colorado   Denver      (-104.9849 39.73923) Credit Repair   Credit Re… Credit Rep… POI      </span></span>
<span><span class='c'>#&gt;  7 Connectic… Hartford&lt;b…  (-72.6822 41.76405) State of Conne… State of … State of C… POI      </span></span>
<span><span class='c'>#&gt;  8 Delaware   Dover       (-75.51972 39.15731) Delaware Legis… Delaware … Delaware L… POI      </span></span>
<span><span class='c'>#&gt;  9 Hawaii     Honolulu    (-157.8574 21.30744) Queen Liliuoka… Queen Lil… Queen Lili… POI      </span></span>
<span><span class='c'>#&gt; 10 Florida    Tallahassee  (-84.2813 30.43812) Florida Capito… Florida C… Florida Ca… POI      </span></span>
<span><span class='c'>#&gt; # ℹ 40 more rows</span></span>
<span><span class='c'>#&gt; # ℹ 18 more variables: type_field &lt;chr&gt;, place_name &lt;chr&gt;, add_num &lt;chr&gt;, address &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   block &lt;chr&gt;, sector &lt;chr&gt;, neighborhood &lt;chr&gt;, district &lt;chr&gt;, city &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   metro_area &lt;chr&gt;, subregion &lt;chr&gt;, region &lt;chr&gt;, region_abbr &lt;chr&gt;, territory &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   postal &lt;chr&gt;, postal_ext &lt;chr&gt;, country_name &lt;chr&gt;, country_code &lt;chr&gt;</span></span></pre>

Alternatively, you can accomplish this using a more esoteric and tidyverse-centric approach. The below is an option that uses [`mutate()`](https://dplyr.tidyverse.org/reference/mutate.html) to create a new column which is an sf object. Then, it uses [`tidyr::unnest()`](https://tidyr.tidyverse.org/reference/unnest.html) to unnest the newly created sf column.

<pre class='chroma'>
<span><span class='nv'>capitals</span> <span class='o'>|&gt;</span></span>
<span>  <span class='nf'><a href='https://dplyr.tidyverse.org/reference/mutate.html'>mutate</a></span><span class='o'>(</span></span>
<span>    address_info <span class='o'>=</span> <span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_geometry.html'>st_drop_geometry</a></span><span class='o'>(</span></span>
<span>      <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html'>reverse_geocode</a></span><span class='o'>(</span><span class='nv'>geometry</span><span class='o'>)</span></span>
<span>    <span class='o'>)</span></span>
<span>  <span class='o'>)</span> <span class='o'>|&gt;</span></span>
<span>  <span class='nf'>tidyr</span><span class='nf'>::</span><span class='nf'><a href='https://tidyr.tidyverse.org/reference/unnest.html'>unnest</a></span><span class='o'>(</span><span class='nv'>address_info</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Simple feature collection with 50 features and 24 fields</span></span>
<span><span class='c'>#&gt; Geometry type: POINT</span></span>
<span><span class='c'>#&gt; Dimension:     XY</span></span>
<span><span class='c'>#&gt; Bounding box:  xmin: -157.8574 ymin: 21.30744 xmax: -69.78169 ymax: 58.3016</span></span>
<span><span class='c'>#&gt; Geodetic CRS:  WGS 84</span></span>
<span><span class='c'>#&gt; # A tibble: 50 × 25</span></span>
<span><span class='c'>#&gt;    name       description             geometry match_addr      long_label short_label addr_type</span></span>
<span><span class='c'>#&gt;    &lt;chr&gt;      &lt;chr&gt;                &lt;POINT [°]&gt; &lt;chr&gt;           &lt;chr&gt;      &lt;chr&gt;       &lt;chr&gt;    </span></span>
<span><span class='c'>#&gt;  1 Alabama    Montgomery  (-86.30057 32.37772) Psiquicos del … Psiquicos… Psiquicos … POI      </span></span>
<span><span class='c'>#&gt;  2 Alaska     Juneau       (-134.4202 58.3016) Gold Creek Cafe Gold Cree… Gold Creek… POI      </span></span>
<span><span class='c'>#&gt;  3 Arizona    Phoenix      (-112.097 33.44814) Arizona Capito… Arizona C… Arizona Ca… POI      </span></span>
<span><span class='c'>#&gt;  4 Arkansas   Little Rock (-92.28899 34.74661) Arkansas State… Arkansas … Arkansas S… POI      </span></span>
<span><span class='c'>#&gt;  5 California Sacramento  (-121.4936 38.57667) California Sta… Californi… California… POI      </span></span>
<span><span class='c'>#&gt;  6 Colorado   Denver      (-104.9849 39.73923) Credit Repair   Credit Re… Credit Rep… POI      </span></span>
<span><span class='c'>#&gt;  7 Connectic… Hartford&lt;b…  (-72.6822 41.76405) State of Conne… State of … State of C… POI      </span></span>
<span><span class='c'>#&gt;  8 Delaware   Dover       (-75.51972 39.15731) Delaware Legis… Delaware … Delaware L… POI      </span></span>
<span><span class='c'>#&gt;  9 Hawaii     Honolulu    (-157.8574 21.30744) Queen Liliuoka… Queen Lil… Queen Lili… POI      </span></span>
<span><span class='c'>#&gt; 10 Florida    Tallahassee  (-84.2813 30.43812) Florida Capito… Florida C… Florida Ca… POI      </span></span>
<span><span class='c'>#&gt; # ℹ 40 more rows</span></span>
<span><span class='c'>#&gt; # ℹ 18 more variables: type_field &lt;chr&gt;, place_name &lt;chr&gt;, add_num &lt;chr&gt;, address &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   block &lt;chr&gt;, sector &lt;chr&gt;, neighborhood &lt;chr&gt;, district &lt;chr&gt;, city &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   metro_area &lt;chr&gt;, subregion &lt;chr&gt;, region &lt;chr&gt;, region_abbr &lt;chr&gt;, territory &lt;chr&gt;,</span></span>
<span><span class='c'>#&gt; #   postal &lt;chr&gt;, postal_ext &lt;chr&gt;, country_name &lt;chr&gt;, country_code &lt;chr&gt;</span></span></pre>

## Reverse geocoding a matrix of coordinates

There are other times where you may have your coordinates stored as a matrix with two columns. [`reverse_geocode()`](https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html) accepts a 2 column numeric matrix as an input to its `location` argument.

For the sake of example, the coordinates are extracted as a matrix using [`sf::st_coordinates()`](https://r-spatial.github.io/sf/reference/st_coordinates.html).

<pre class='chroma'>
<span><span class='nv'>coords</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://r-spatial.github.io/sf/reference/st_coordinates.html'>st_coordinates</a></span><span class='o'>(</span><span class='nv'>capitals</span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://rdrr.io/r/utils/head.html'>head</a></span><span class='o'>(</span><span class='nv'>coords</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt;               X        Y</span></span>
<span><span class='c'>#&gt; [1,]  -86.30057 32.37772</span></span>
<span><span class='c'>#&gt; [2,] -134.42021 58.30160</span></span>
<span><span class='c'>#&gt; [3,] -112.09696 33.44814</span></span>
<span><span class='c'>#&gt; [4,]  -92.28899 34.74661</span></span>
<span><span class='c'>#&gt; [5,] -121.49363 38.57667</span></span>
<span><span class='c'>#&gt; [6,] -104.98486 39.73923</span></span></pre>

Pass this matrix directly into [`reverse_geocode()`](https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html).

<pre class='chroma'>
<span><span class='nv'>geocoded</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgisgeocode/man/reverse_geocode.html'>reverse_geocode</a></span><span class='o'>(</span><span class='nv'>coords</span><span class='o'>)</span></span>
<span><span class='nf'><a href='https://pillar.r-lib.org/reference/glimpse.html'>glimpse</a></span><span class='o'>(</span><span class='nv'>geocoded</span><span class='o'>)</span></span></pre>
<pre class='chroma'>
<span><span class='c'>#&gt; Rows: 50</span></span>
<span><span class='c'>#&gt; Columns: 23</span></span>
<span><span class='c'>#&gt; $ match_addr   &lt;chr&gt; "Psiquicos del Amor y Sanacion", "Gold Creek Cafe", "Arizona Capitol Mus…</span></span>
<span><span class='c'>#&gt; $ long_label   &lt;chr&gt; "Psiquicos del Amor y Sanacion, 600 Dexter Ave, Montgomery, AL, 36130, U…</span></span>
<span><span class='c'>#&gt; $ short_label  &lt;chr&gt; "Psiquicos del Amor y Sanacion", "Gold Creek Cafe", "Arizona Capitol Mus…</span></span>
<span><span class='c'>#&gt; $ addr_type    &lt;chr&gt; "POI", "POI", "POI", "POI", "POI", "POI", "POI", "POI", "POI", "POI", "P…</span></span>
<span><span class='c'>#&gt; $ type_field   &lt;chr&gt; "Other Professional Place", "Restaurant", "Specialty Store", "Government…</span></span>
<span><span class='c'>#&gt; $ place_name   &lt;chr&gt; "Psiquicos del Amor y Sanacion", "Gold Creek Cafe", "Arizona Capitol Mus…</span></span>
<span><span class='c'>#&gt; $ add_num      &lt;chr&gt; "600", "709", "1700", "500", "1315", "101", "210", "411", "415", "", "21…</span></span>
<span><span class='c'>#&gt; $ address      &lt;chr&gt; "600 Dexter Ave", "709 W 9th St", "1700 W Washington St", "500 Capitol M…</span></span>
<span><span class='c'>#&gt; $ block        &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ sector       &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ neighborhood &lt;chr&gt; "", "", "", "", "Downtown Sacramento", "", "Downtown Hartford", "", "Dow…</span></span>
<span><span class='c'>#&gt; $ district     &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ city         &lt;chr&gt; "Montgomery", "Juneau", "Phoenix", "Little Rock", "Sacramento", "Denver"…</span></span>
<span><span class='c'>#&gt; $ metro_area   &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ subregion    &lt;chr&gt; "Montgomery County", "Juneau City and Borough", "Maricopa County", "Pula…</span></span>
<span><span class='c'>#&gt; $ region       &lt;chr&gt; "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "C…</span></span>
<span><span class='c'>#&gt; $ region_abbr  &lt;chr&gt; "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "HI", "FL", "GA", "ID", …</span></span>
<span><span class='c'>#&gt; $ territory    &lt;chr&gt; "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", …</span></span>
<span><span class='c'>#&gt; $ postal       &lt;chr&gt; "36130", "99801", "85007", "72201", "95814", "80203", "06106", "19901", …</span></span>
<span><span class='c'>#&gt; $ postal_ext   &lt;chr&gt; "", "", "", "", "", "", "1501", "", "", "", "", "0001", "", "", "", "150…</span></span>
<span><span class='c'>#&gt; $ country_name &lt;chr&gt; "United States", "United States", "United States", "United States", "Uni…</span></span>
<span><span class='c'>#&gt; $ country_code &lt;chr&gt; "USA", "USA", "USA", "USA", "USA", "USA", "USA", "USA", "USA", "USA", "U…</span></span>
<span><span class='c'>#&gt; $ geometry     &lt;POINT [°]&gt; POINT (-86.30052 32.37772), POINT (-134.4203 58.30155), POINT (-11…</span></span></pre>
