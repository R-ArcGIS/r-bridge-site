# `arcgislayers`: an open source package for ArcGIS Location Services

## Summary

arcgislayers is an open source package as part of Environmental Systems Research Institute’s (Esri) R-ArcGIS Bridge project. arcgislayers enables developers to interact with ArcGIS data services directly from R. With arcgislayers, users can read, write, and administer remotely hosted data directly from R using native objects.

## Statement of need

In the evolving landscape of geospatial analysis, a critical shift towards cloud-native infrastructure has emerged, characterized by the exposure of data via REST APIs. Esri’s ArcGIS Location Services characterized by ArcGIS Platform embody this transition. Location services are accessible via REST API endpoints which which are language agnostic.

While existing solutions like arcgisbinding enable reading and writing of ArcGIS hosted data, they present limitations (Aydin et al.). Notably, arcgisbinding relies on an ArcGIS Pro license which is confined to a Windows operating system, and does not support any additional administration of hosted data services.

Moreover, the community-driven endeavors such as esri2sf, arcpullr, among others, strive to bridge this gap (CITE). However, these efforts fall short in delivering comprehensive, officially supported, and high-performance alternatives.

arcgislayers is an official, Esri-backed, open-source R package designed to interact with ArcGIS Image Servers and Feature Services. Leveraging the REST services offered by ArcGIS, arcgislayers empowers developers to seamlessly administer, read, and write data without the constraints of proprietary licenses or operating systems.

# Implementation

arcgislayers supports both Image Servers and Feature Services. When reading raster imagery, arcgislayers returns objects of class `SpatRaster` from the terra package. arcgislayers’ vector capabilities are much more sophisticated, however.

In the r-spatial ecosystem, sf objects are the de facto representation of geometric objects with associated attributes. As such, arcgislayers utilizes sf objects and data.frames to represent spatial and a-spatial data respectively. Due to the ubiquity of sf objects additional geometry types are not supported directly but can be via wk (edzer, probably bivand somewhere inhere dunnington).

The ArcGIS REST API defines a number of JSON objects that are understood by the endpoints. Notably, the REST APIs have their own definitions for geometries objects. Underpinning arcgislayers is the R package arcgisutils which is used for serializing data.frame and sf objects into Esri JSON formats. arcgisutils also provides utilities for deserializing Esri JSON returned from the REST APIs into sf or data.frame objects.

The de/serialization provided by arcgisutils enables seamless reading and writing of geospatial data with ArcGIS Location Services.

<pre class='chroma'>
<span><span class='nf'>sf</span><span class='nf'>::</span><span class='nf'><a href='https://r-spatial.github.io/sf/reference/st.html'>st_point</a></span><span class='o'>(</span><span class='nf'><a href='https://rdrr.io/r/base/c.html'>c</a></span><span class='o'>(</span><span class='m'>3.0</span>, <span class='m'>0.14</span><span class='o'>)</span><span class='o'>)</span> <span class='o'>|&gt;</span> </span>
<span>  <span class='nf'>arcgisutils</span><span class='nf'>::</span><span class='nf'><a href='https://rdrr.io/pkg/arcgisutils/man/as_esri_geometry.html'>as_esri_geometry</a></span><span class='o'>(</span><span class='o'>)</span> <span class='o'>|&gt;</span> </span>
<span>  <span class='nf'>jsonify</span><span class='nf'>::</span><span class='nf'><a href='https://rdrr.io/pkg/jsonify/man/pretty_json.html'>pretty_json</a></span><span class='o'>(</span><span class='o'>)</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; {</span></span>
<span><span class='c'>#&gt;     "x": 3.0,</span></span>
<span><span class='c'>#&gt;     "y": 0.14</span></span>
<span><span class='c'>#&gt; }</span></span></pre>

## Example usage

<pre class='chroma'>
<span><span class='kr'><a href='https://rdrr.io/r/base/library.html'>library</a></span><span class='o'>(</span><span class='nv'><a href='https://developers.arcgis.com/r-bridge'>arcgislayers</a></span><span class='o'>)</span></span>
<span></span>
<span><span class='nv'>url</span> <span class='o'>&lt;-</span> <span class='s'>"https://services3.arcgis.com/ZvidGQkLaDJxRSJ2/arcgis/rest/services/PLACES_LocalData_for_BetterHealth/FeatureServer/0"</span></span>
<span></span>
<span><span class='nv'>flayer</span> <span class='o'>&lt;-</span> <span class='nf'><a href='https://rdrr.io/pkg/arcgislayers/man/arc_open.html'>arc_open</a></span><span class='o'>(</span><span class='nv'>url</span><span class='o'>)</span></span>
<span><span class='nv'>flayer</span></span></pre>

<pre class='chroma'>
<span><span class='c'>#&gt; &lt;FeatureLayer&gt;</span></span>
<span><span class='c'>#&gt; Name: PlacePoints</span></span>
<span><span class='c'>#&gt; Geometry Type: esriGeometryPoint</span></span>
<span><span class='c'>#&gt; CRS: 3785</span></span>
<span><span class='c'>#&gt; Capabilities: Query,Extract</span></span></pre>

------------------------------------------------------------------------

Notes

- Aydin et al introduce arcgisbinding which provides a binding to ArcGIS pro enabling the reading and writing of ArcGIS Proprietary data formats and on the fly geospatial transformations using the transformation engine

- We’re seeing a shift towards cloud-native geospatial analysis data infrastructure which are exposed via rest apis

- Esri provides very useful technology via ArcGIS Location Services. Location services are exposed via rest APIs which are well documented. Endpoints can be both public or private depending on the hosting solution and authentication used.

- REST services provide a language agnostic interface to proprietary code allowing the development of completely open source bindings to the services

- While arcgisbinding provides a way for users of R *and* ArcGIS Pro to read image and feature services it is fairly limited. Noteably, the use of arcgisbinding requires an ArcGIS Pro license which itself requires a window machine. Further, arcgisbinding does not provide further capabilities for hosted data management.

- arcgislayers builds upon the REST service provided by ArcGIS. arcgislayers is an open source R package for interacting with ArcGIS image servers and Feature services.

- there are a number of community driven efforts to address this gap which are notably esri2sf, arcpullr, among others.

- arcgislayers is an official, esri supported, and highly performant alternative to these packages
